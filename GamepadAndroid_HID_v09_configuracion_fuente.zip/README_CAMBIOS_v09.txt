GAMEPAD ANDROID - fuente v0.9 (configuración)

Cambios incorporados sobre el ZIP proporcionado:
- Pantalla de configuración accesible desde el mando.
- Control de tamaño de botones, guardado en preferencias locales.
- Control de sensibilidad de palancas, guardado en preferencias locales.
- Restaurar valores predeterminados.
- Acción APAGAR Y SALIR en la pantalla del mando.
- Icono vectorial de mando con estilo neón.
- Versión incrementada a 0.9-settings.

IMPORTANTE: este ZIP contiene el CÓDIGO FUENTE, no un APK instalado.
No se pudo ejecutar una compilación Android en este entorno; por eso esta versión no debe considerarse compilada ni probada en una TV Box. La edición libre de posiciones, servicio persistente en segundo plano y comprobación funcional de todos los informes HID siguen pendientes de validación.
Para compilar, abrir la carpeta GamepadAndroidNative_v2 en Android Studio y sincronizar Gradle.
