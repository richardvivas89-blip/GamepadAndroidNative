package com.example.gamepadandroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Gamepad Android v0.2
 * Sender: Wi-Fi TCP or Bluetooth Classic RFCOMM SPP.
 * Receiver: TCP server on port 45820 for testing the real local-network protocol.
 * This does not emulate Bluetooth HID or inject input into unrelated TV apps.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var eventLog: TextView
    private var tcpSocket: Socket? = null
    private var tcpOut: OutputStream? = null
    private var btSocket: BluetoothSocket? = null
    private var btOut: OutputStream? = null
    private var serverSocket: ServerSocket? = null
    @Volatile private var receiverRunning = false
    private var transport = "none"
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var hidProfileAvailable = false
    private var hidRegistered = false
    private var hidTarget: BluetoothDevice? = null
    private val hidExecutor: Executor = Executors.newSingleThreadExecutor()
    private val heldButtons = mutableSetOf<String>()
    private var axisLX = 0; private var axisLY = 0
    private var axisRX = 0; private var axisRY = 0
    private var hidProxy: BluetoothHidDevice? = null
    private val hidDeviceCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            hidRegistered = registered
            runOnUiThread {
                if (::status.isInitialized) status.text =
                    if (registered) "Mando HID registrado. Seleccioná el teléfono en la TV Box y conectá."
                    else "El registro HID no está activo. Mantené la aplicación abierta."
            }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            runOnUiThread {
                if (device != null && state == BluetoothProfile.STATE_CONNECTED) {
                    hidTarget = device
                    status.text = "Mando HID conectado · ${device.name ?: "TV Box"}"
                    buildSettingsUi()
                } else if (device != null && state == BluetoothProfile.STATE_DISCONNECTED) {
                    if (::status.isInitialized) status.text = "Mando HID desconectado de ${device.name ?: "TV Box"}."
                }
            }
        }
    }
    private val hidCallback = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE && proxy is BluetoothHidDevice) {
                hidProxy = proxy
                hidProfileAvailable = true
                runOnUiThread {
                    if (::status.isInitialized) status.text = "Perfil HID disponible. Elegí el TV Box para registrar el mando."
                }
            }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidProxy = null
                hidProfileAvailable = false
                runOnUiThread {
                    if (::status.isInitialized) status.text = "El servicio Bluetooth HID se desconectó."
                }
            }
        }
    }
    private val adapter: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        buildBluetoothUi()
        requestBluetoothPermissionsIfNeeded()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 24, 22, 20)
        setBackgroundColor(0xFF0B0E14.toInt())
    }

    private fun text(value: String, size: Float = 15f) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(0xFFEEF2F8.toInt())
        includeFontPadding = true
        setPadding(4, 6, 4, 6)
    }


    /** Primera pantalla: emparejamiento/conexión Bluetooth antes de mostrar el mando. */
    private fun buildBluetoothUi(message: String = "Conectá el TV Box para continuar") {
        val root = baseLayout()
        root.gravity = Gravity.CENTER
        root.setPadding(24, 12, 24, 12)
        root.addView(text("🎮  GAMEPAD ANDROID", 29f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF43D9FF.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(text("PANTALLA 1 · CONEXIÓN BLUETOOTH", 17f).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        status = text(message, 15f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7DD.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(actionButton("CONECTAR Y REGISTRAR MANDO") { startHidRegistrationAndSelectHost() },
            LinearLayout.LayoutParams(-1, 52).apply { setMargins(30, 10, 30, 6) })
        root.addView(actionButton("COMPROBAR SOPORTE BLUETOOTH HID") { checkHidSupport() },
            LinearLayout.LayoutParams(-1, 48).apply { setMargins(30, 4, 30, 6) })
        root.addView(actionButton("ABRIR AJUSTES DE BLUETOOTH") {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
            catch (_: Exception) { status.text = "No se pudieron abrir los ajustes de Bluetooth." }
        }, LinearLayout.LayoutParams(-1, 48).apply { setMargins(30, 4, 30, 8) })
        root.addView(text("Esta versión intenta registrar un mando HID real. La compatibilidad depende del Android y de la TV Box.", 12f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF8B9AB5.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private val prefs by lazy { getSharedPreferences("gamepad_settings", MODE_PRIVATE) }
    private fun buttonSize(): Int = prefs.getInt("button_size", 52).coerceIn(40, 88)
    private fun sensitivity(): Float = prefs.getInt("sensitivity", 100).coerceIn(25, 200) / 100f

    /** Pantalla 2: configuración persistente del mando. */
    private fun buildSettingsUi() {
        val root = baseLayout()
        root.addView(text("GAMEPAD ANDROID", 26f).apply { gravity = Gravity.CENTER; setTextColor(0xFF43D9FF.toInt()) }, matchWrap())
        root.addView(text("PANTALLA 2 · CONFIGURACIÓN", 16f).apply { gravity = Gravity.CENTER }, matchWrap())
        root.addView(text("Tamaño de los botones", 15f), matchWrap())
        val sizeLabel = text("${buttonSize()} dp", 13f); root.addView(sizeLabel, matchWrap())
        root.addView(SeekBar(this).apply {
            max = 48; progress = buttonSize() - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { sizeLabel.text = "${progress + 40} dp"; if (fromUser) prefs.edit().putInt("button_size", progress + 40).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, matchWrap())
        root.addView(text("Sensibilidad de las palancas", 15f), matchWrap())
        val sensLabel = text("${(sensitivity() * 100).toInt()} %", 13f); root.addView(sensLabel, matchWrap())
        root.addView(SeekBar(this).apply {
            max = 175; progress = (sensitivity() * 100).toInt() - 25
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { sensLabel.text = "${progress + 25} %"; if (fromUser) prefs.edit().putInt("sensitivity", progress + 25).apply() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, matchWrap())
        root.addView(text("Los cambios se guardan automáticamente. El tamaño se aplica al volver al mando; la sensibilidad se aplica a las palancas.", 12f), matchWrap())
        root.addView(actionButton("ABRIR MANDO VIRTUAL") { buildControllerUi() }, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 12, 0, 6) })
        root.addView(actionButton("RESTAURAR VALORES PREDETERMINADOS") { prefs.edit().putInt("button_size", 52).putInt("sensitivity", 100).apply(); buildSettingsUi() }, matchWrap())
        root.addView(actionButton("VOLVER A CONEXIÓN") { buildBluetoothUi() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun buildControllerUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(0xFF080D18.toInt())
        }
        status = text("GAMEPAD ANDROID  •  BLUETOOTH SIN CONECTAR", 14f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF43D9FF.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 36))

        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toolbar.addView(actionButton("VOLVER A BLUETOOTH") { disconnect(); buildBluetoothUi("Desconectado. Elegí el TV Box para volver a conectar.") }, LinearLayout.LayoutParams(0, 44, 1f))
        toolbar.addView(actionButton("CONFIGURACIÓN") { buildSettingsUi() }, LinearLayout.LayoutParams(0, 44, 1f))
        toolbar.addView(actionButton("APAGAR Y SALIR") { disconnect(); try { hidProxy?.unregisterApp() } catch (_: Exception) {}; finishAffinity() }, LinearLayout.LayoutParams(0, 44, 1f))
        root.addView(toolbar)

        val board = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 0)
        }
        // Left grip: directional pad and shoulder controls.
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        left.addView(text("D-PAD", 11f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val dpad = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        listOf("" to "", "▲" to "UP", "" to "", "◀" to "LEFT", "●" to "CENTER", "▶" to "RIGHT", "" to "", "▼" to "DOWN", "" to "").forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            dpad.addView(b, GridLayout.LayoutParams().apply { width = buttonSize() + 8; height = buttonSize(); setMargins(4, 4, 4, 4) })
        }
        left.addView(dpad)
        val shouldersL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("L1", "L2").forEach { shouldersL.addView(touchButton(it, it), LinearLayout.LayoutParams(76, 44).apply { setMargins(4, 4, 4, 4) }) }
        left.addView(shouldersL)
        board.addView(left, LinearLayout.LayoutParams(0, -1, 1f))

        // Center: twin touch sticks; movement is sent as HID axis reports.
        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        center.addView(StickView("LX", "LY"), LinearLayout.LayoutParams(0, 170, 1f).apply { setMargins(4, 0, 4, 0) })
        center.addView(StickView("RX", "RY"), LinearLayout.LayoutParams(0, 170, 1f).apply { setMargins(4, 0, 4, 0) })
        board.addView(center, LinearLayout.LayoutParams(0, -1, 2f))

        // Right grip: Xbox ABXY layout and system buttons.
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        right.addView(text("BOTONES", 11f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val xy = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        listOf("" to "", "Y" to "Y", "" to "", "X" to "X", "" to "", "B" to "B", "" to "", "A" to "A", "" to "").forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            if (key.isNotEmpty()) b.setTextColor(when (key) { "A" -> 0xFF47E58A.toInt(); "B" -> 0xFFFF647C.toInt(); "X" -> 0xFF48A9FF.toInt(); else -> 0xFFFFD34F.toInt() })
            xy.addView(b, GridLayout.LayoutParams().apply { width = buttonSize() + 6; height = buttonSize(); setMargins(4, 4, 4, 4) })
        }
        right.addView(xy)
        val shouldersR = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("R1", "R2").forEach { shouldersR.addView(touchButton(it, it), LinearLayout.LayoutParams(76, 44).apply { setMargins(4, 4, 4, 4) }) }
        right.addView(shouldersR)
        val system = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("SELECT", "START").forEach { system.addView(touchButton(it, it), LinearLayout.LayoutParams(88, 42).apply { setMargins(4, 4, 4, 4) }) }
        right.addView(system)
        board.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Mando HID de prueba · mantené la app abierta. La compatibilidad depende de la TV Box.", 10f).apply {
            setTextColor(0xFF9AA8BF.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun touchButton(label: String, key: String): Button = Button(this).apply {
        text = label
        textSize = when {
            label.length >= 6 -> 12f
            label.length >= 3 -> 15f
            else -> 22f
        }
        gravity = Gravity.CENTER
        includeFontPadding = false
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        isAllCaps = false
        stateListAnimator = null
        setTextColor(when (key) {
            "A" -> 0xFF062617.toInt()
            "B" -> 0xFF350811.toInt()
            "X" -> 0xFF061D35.toInt()
            "Y" -> 0xFF342700.toInt()
            else -> 0xFFF4F8FF.toInt()
        })
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = if (key in listOf("A", "B", "X", "Y")) 42f else 14f
            setColor(when (key) {
                "A" -> 0xFF063B2A.toInt()
                "B" -> 0xFF421421.toInt()
                "X" -> 0xFF0B3157.toInt()
                "Y" -> 0xFF40330A.toInt()
                else -> 0xFF14243D.toInt()
            })
            setStroke(3, when (key) {
                "A" -> 0xFF2BEA98.toInt()
                "B" -> 0xFFFF466B.toInt()
                "X" -> 0xFF22A8FF.toInt()
                "Y" -> 0xFFFFC933.toInt()
                else -> 0xFF168BFF.toInt()
            })
        }
        setPadding(4, 2, 4, 2)
        stateListAnimator = null
        setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    sendButton(key, true)
                    v.alpha = 0.72f
                    v.scaleX = 0.94f; v.scaleY = 0.94f
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    sendButton(key, false)
                    v.alpha = 1f
                    v.scaleX = 1f; v.scaleY = 1f
                    true
                }
                else -> true
            }
        }
    }

    private inner class StickView(private val xAxis: String, private val yAxis: String) : View(this@MainActivity) {
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C2A40.toInt(); style = Paint.Style.FILL }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF43D9FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
        private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF324967.toInt(); style = Paint.Style.FILL }
        private var px = 0f; private var py = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val radius = (minOf(width, height) * .37f)
            canvas.drawCircle(cx, cy, radius, ring); canvas.drawCircle(cx, cy, radius, outline)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, knob)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, outline)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val radius = minOf(width, height) * .37f
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    px = ((event.x - width / 2f) / radius).coerceIn(-1f, 1f)
                    py = ((event.y - height / 2f) / radius).coerceIn(-1f, 1f)
                    updateAxis(xAxis, px)
                    updateAxis(yAxis, py)
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    px = 0f; py = 0f
                    updateAxis(xAxis, 0f)
                    updateAxis(yAxis, 0f)
                    invalidate(); return true
                }
            }
            return true
        }
    }

    private fun buildReceiverUi() {
        disconnect()
        val outer = baseLayout()
        outer.addView(text("RECEPTOR WI-FI · GAMEPAD ANDROID", 20f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF5EEAD4.toInt())
        }, matchWrap())
        val ip = localIpv4() ?: "No se detectó IP Wi-Fi"
        outer.addView(text("IP de este dispositivo: $ip\nPuerto TCP: 45820\nConectá el mando desde otro dispositivo usando esta IP."), matchWrap())
        status = text("Receptor detenido")
        outer.addView(status, matchWrap())
        outer.addView(actionButton("Iniciar receptor") { startReceiver() }, matchWrap())
        outer.addView(actionButton("Detener receptor") { stopReceiver() }, matchWrap())
        outer.addView(actionButton("Volver al mando") { stopReceiver(); buildControllerUi() }, matchWrap())
        outer.addView(text("Eventos recibidos:", 17f), matchWrap())
        eventLog = text("Todavía no llegaron eventos.")
        outer.addView(eventLog, matchWrap())
        setContentView(ScrollView(this).apply { addView(outer) })
    }

    private fun startReceiver() {
        if (receiverRunning) { status.text = "Receptor activo en puerto 45820"; return }
        receiverRunning = true
        status.text = "Iniciando receptor…"
        thread(name = "gamepad-wifi-receiver") {
            try {
                val server = ServerSocket()
                server.reuseAddress = true
                server.bind(InetSocketAddress(45820))
                serverSocket = server
                runOnUiThread { status.text = "Receptor activo · puerto 45820" }
                while (receiverRunning) {
                    val client = server.accept()
                    thread(name = "gamepad-client") { handleClient(client) }
                }
            } catch (e: Exception) {
                if (receiverRunning) runOnUiThread {
                    status.text = "No se pudo iniciar receptor: ${e.localizedMessage ?: "error"}"
                }
            } finally {
                receiverRunning = false
                try { serverSocket?.close() } catch (_: Exception) {}
                serverSocket = null
            }
        }
    }

    private fun handleClient(client: Socket) {
        val peer = client.inetAddress?.hostAddress ?: "cliente"
        runOnUiThread { appendEvent("Conectado: $peer") }
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            while (receiverRunning) {
                val line = reader.readLine() ?: break
                runOnUiThread { appendEvent(line) }
            }
        } catch (e: Exception) {
            runOnUiThread { appendEvent("Conexión cerrada: ${e.localizedMessage ?: "desconocida"}") }
        } finally {
            try { client.close() } catch (_: Exception) {}
            runOnUiThread { appendEvent("Desconectado: $peer") }
        }
    }

    private fun appendEvent(line: String) {
        if (!::eventLog.isInitialized) return
        val old = eventLog.text.toString()
        val lines = (if (old == "Todavía no llegaron eventos.") emptyList() else old.lines()) + line
        eventLog.text = lines.takeLast(35).joinToString("\n")
    }

    private fun stopReceiver() {
        receiverRunning = false
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        if (::status.isInitialized) status.text = "Receptor detenido"
    }

    private fun localIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = if (label.length > 22) 12f else 14f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        gravity = Gravity.CENTER
        isAllCaps = false
        includeFontPadding = false
        minHeight = 44
        minimumHeight = 44
        minWidth = 0
        minimumWidth = 0
        setPadding(14, 10, 14, 10)
        stateListAnimator = null
        setTextColor(0xFFEEF2F8.toInt())
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(0xFF101D32.toInt())
            setStroke(2, 0xFF168BFF.toInt())
        }
        setOnClickListener { click() }
    }

    private fun connectWifi() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().toIntOrNull() ?: 45820
        if (host.isBlank()) { status.text = "Escribí la IP del dispositivo receptor."; return }
        status.text = "Conectando por Wi-Fi…"
        thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 4000)
                val out = s.getOutputStream()
                try { tcpSocket?.close() } catch (_: Exception) {}
                tcpSocket = s; tcpOut = out; transport = "wifi"
                runOnUiThread { status.text = "Conectado por Wi-Fi · $host:$port" }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":2}")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Wi-Fi no conectado: ${e.localizedMessage ?: "error"}" }
            }
        }
    }

    /** Diagnóstico: comprueba si Android expone el perfil HID Device. No registra todavía un mando. */
    private fun checkHidSupport() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no dispone de Bluetooth."; return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "Bluetooth HID Device requiere Android 9 o posterior."; return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé el permiso Bluetooth y volvé a comprobar HID."; return
        }
        try {
            status.text = "Comprobando si Android ofrece Bluetooth HID…"
            val requested = a.getProfileProxy(this, hidCallback, BluetoothProfile.HID_DEVICE)
            if (!requested) {
                status.text = "Android no pudo abrir el perfil HID Device en este teléfono. No se modificó el emparejamiento."
            } else {
                status.text = "Solicitud HID enviada. Esperá unos segundos; el resultado aparecerá aquí."
            }
        } catch (e: SecurityException) {
            status.text = "Permiso Bluetooth insuficiente para comprobar HID."
        } catch (e: Exception) {
            status.text = "No se pudo comprobar HID: ${e.localizedMessage ?: "error del sistema"}"
        }
    }

    private fun startHidRegistrationAndSelectHost() {
        val a = adapter
        if (a == null || !a.isEnabled) {
            status.text = "Activá Bluetooth en Ajustes y volvé a intentarlo."
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "Bluetooth HID Device requiere Android 9 o posterior."
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé el permiso Bluetooth y volvé a pulsar el botón."
            return
        }
        if (hidProxy == null) {
            status.text = "Abriendo servicio HID. Esperá unos segundos y volvé a pulsar."
            try { a.getProfileProxy(this, hidCallback, BluetoothProfile.HID_DEVICE) }
            catch (e: Exception) { status.text = "No se pudo abrir HID: ${e.localizedMessage}"; return }
            return
        }
        registerHidAndSelectHost()
    }

    private fun registerHidAndSelectHost() {
        val proxy = hidProxy
        if (proxy == null) { status.text = "El servicio HID aún no está listo. Volvé a pulsar."; return }
        try {
            val descriptor = byteArrayOf(
                0x05, 0x01, 0x09, 0x05, 0xA1.toByte(), 0x01,
                0x85.toByte(), 0x01, 0x05, 0x09, 0x19, 0x01, 0x29, 0x10,
                0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x10,
                0x81.toByte(), 0x02, 0x05, 0x01, 0x09, 0x39, 0x15, 0x00,
                0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
                0x75, 0x04, 0x95.toByte(), 0x01, 0x81.toByte(), 0x42,
                0x65, 0x00, 0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x33, 0x09, 0x34,
                0x15, 0x81.toByte(), 0x25, 0x7F, 0x75, 0x08, 0x95.toByte(), 0x04, 0x81.toByte(), 0x02,
                0xC0.toByte()
            )
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "Gamepad Android", "Bluetooth HID Gamepad", "OpenAI", 0x08, descriptor
            )
            val accepted = proxy.registerApp(sdp, null, null, hidExecutor, hidDeviceCallback)
            status.text = if (accepted) "Registro HID solicitado. Esperá el mensaje de registro y elegí la TV Box en sus ajustes Bluetooth."
                else "Android rechazó la solicitud de registro HID."
            showBluetoothDevicesForHid()
        } catch (e: SecurityException) {
            status.text = "Permiso Bluetooth insuficiente: ${e.localizedMessage ?: "denegado"}"
        } catch (e: Exception) {
            status.text = "No se pudo registrar HID: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun showBluetoothDevicesForHid() {
        val a = adapter ?: return
        try {
            val devices = a.bondedDevices.toList()
            if (devices.isEmpty()) { status.text = "Emparejá primero la TV Box desde Ajustes Bluetooth."; return }
            val labels = devices.map { "${it.name ?: "Dispositivo"} · ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("TV Box emparejada (HID)")
                .setItems(labels) { _, which ->
                    val device = devices[which]
                    hidTarget = device
                    val ok = try { hidProxy?.connect(device) ?: false } catch (_: Exception) { false }
                    status.text = if (ok) "Solicitud de conexión HID enviada a ${device.name ?: "TV Box"}. Si no conecta, seleccioná el teléfono desde la TV Box."
                        else "No se pudo iniciar desde el teléfono. En la TV Box, buscá y seleccioná el teléfono como mando Bluetooth."
                }.setNegativeButton("Cancelar", null).show()
        } catch (e: Exception) { status.text = "No se pudieron listar dispositivos: ${e.localizedMessage}" }
    }

    private fun updateAxis(axis: String, value: Float) {
        val scaled = (value.coerceIn(-1f, 1f) * 127f * sensitivity()).toInt().coerceIn(-127, 127)
        when (axis) {
            "LX" -> axisLX = scaled
            "LY" -> axisLY = scaled
            "RX" -> axisRX = scaled
            "RY" -> axisRY = scaled
        }
        sendHidReport()
    }

    private fun sendHidReport() {
        val proxy = hidProxy ?: return
        val target = hidTarget ?: return
        if (!hidRegistered) return
        val bitMap = listOf("A", "B", "X", "Y", "L1", "R1", "L2", "R2", "SELECT", "START", "UP", "DOWN", "LEFT", "RIGHT", "CENTER", "HOME")
        var buttons = 0
        bitMap.forEachIndexed { index, name -> if (name in heldButtons) buttons = buttons or (1 shl index) }
        val report = byteArrayOf(
            (buttons and 0xFF).toByte(), ((buttons shr 8) and 0xFF).toByte(),
            (when {
                "UP" in heldButtons && "RIGHT" in heldButtons -> 1
                "RIGHT" in heldButtons && "DOWN" in heldButtons -> 3
                "DOWN" in heldButtons && "LEFT" in heldButtons -> 5
                "LEFT" in heldButtons && "UP" in heldButtons -> 7
                "UP" in heldButtons -> 0
                "RIGHT" in heldButtons -> 2
                "DOWN" in heldButtons -> 4
                "LEFT" in heldButtons -> 6
                else -> 8
            }).toByte(), axisLX.toByte(), axisLY.toByte(), axisRX.toByte(), axisRY.toByte()
        )
        try { proxy.sendReport(target, 1, report) } catch (_: Exception) {}
    }

    private fun showBluetoothDevices() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no tiene Bluetooth."; return }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé permiso Bluetooth y volvé a intentarlo."
            return
        }
        if (!a.isEnabled) { status.text = "Activá Bluetooth en Ajustes y volvé a intentarlo."; return }
        try {
            val devices = a.bondedDevices.toList()
            if (devices.isEmpty()) {
                status.text = "No hay dispositivos emparejados. Emparejá primero el receptor en Ajustes."
                return
            }
            val labels = devices.map { "${it.name ?: "Dispositivo"} · ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Elegí un receptor Bluetooth")
                .setItems(labels) { _, which -> connectBluetooth(devices[which]) }
                .setNegativeButton("Cancelar", null).show()
        } catch (_: SecurityException) { status.text = "Permiso Bluetooth denegado." }
    }

    private fun connectBluetooth(device: BluetoothDevice) {
        status.text = "Conectando Bluetooth…"
        thread {
            try {
                adapter?.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                try { btSocket?.close() } catch (_: Exception) {}
                btSocket = socket; btOut = socket.outputStream; transport = "bluetooth"
                runOnUiThread {
                    status.text = "Bluetooth RFCOMM conectado · ${device.name ?: device.address}"
                    buildControllerUi()
                }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":3}")
            } catch (e: Exception) {
                runOnUiThread { buildBluetoothUi("Bluetooth no conectado: ${e.localizedMessage ?: "error"}. Revisá que el TV Box admita RFCOMM/SPP.") }
            }
        }
    }

    private fun sendButton(name: String, down: Boolean) {
        if (down) heldButtons.add(name) else heldButtons.remove(name)
        sendHidReport()
        if (down && ::status.isInitialized) status.text =
            if (hidRegistered) "Entrada HID: $name" else "Control táctil: $name · HID no registrado"
    }

    private fun sendRaw(message: String) {
        val bytes = (message + "\n").toByteArray(Charsets.UTF_8)
        thread {
            try {
                when (transport) {
                    "wifi" -> synchronized(this) { tcpOut?.write(bytes); tcpOut?.flush() }
                    "bluetooth" -> synchronized(this) { btOut?.write(bytes); btOut?.flush() }
                    else -> { /* Offline preview: no remote transport. */ }
                }
            } catch (e: Exception) {
                runOnUiThread { if (::status.isInitialized) status.text = "Error enviando datos: ${e.localizedMessage ?: "conexión perdida"}" }
            }
        }
    }

    private fun disconnect() {
        transport = "none"
        try { tcpOut?.close() } catch (_: Exception) {}
        try { tcpSocket?.close() } catch (_: Exception) {}
        try { btOut?.close() } catch (_: Exception) {}
        try { btSocket?.close() } catch (_: Exception) {}
        tcpOut = null; tcpSocket = null; btOut = null; btSocket = null
    }

    private fun requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val missing = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 101)
        }
    }

    override fun onDestroy() {
        stopReceiver()
        disconnect()
        try { hidProxy?.unregisterApp() } catch (_: Exception) {}
        try { hidProxy?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (_: Exception) {}
        hidProxy = null
        super.onDestroy()
    }
}
