GAMEPAD ANDROID HID v22
1. Subí este ZIP completo al repositorio o copiá el ZIP fuente a la raíz del repositorio existente.
2. El workflow está en .github/workflows/build.yml y compila el ZIP v22.
3. Ejecutá GitHub Actions y descargá el artefacto GAMEPAD-ANDROID-HID-v22-EDITOR-GRUPOS si la compilación termina correctamente.
La compilación y el funcionamiento deben verificarse en GitHub Actions y en la TV Box real.
