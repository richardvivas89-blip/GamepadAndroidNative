GAMEPAD ANDROID HID v18 - AJUSTE DE DISTRIBUCION

Cambios aplicados sobre la fuente v17:
- Reducción de la altura de cabecera y barras para liberar espacio vertical.
- Controles laterales y sticks con dimensiones más compactas.
- Tamaño base de los botones limitado según la altura disponible en pantalla apaisada.
- Arrastre limitado a los bordes del contenedor para reducir el riesgo de que un botón quede fuera del área visible.
- Se conserva el modo edición rojo y el modo normal azul, además del código de conexión existente.

Pendiente de validar en dispositivo: la compilación y el comportamiento visual real deben probarse mediante GitHub Actions y en el teléfono/TV Box.
