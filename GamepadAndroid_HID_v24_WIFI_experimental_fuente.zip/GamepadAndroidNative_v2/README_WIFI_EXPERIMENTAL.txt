GAMEPAD ANDROID v24 — etapa Wi-Fi experimental

Base: fuente v24 de controles personalizados.

Implementado en esta etapa:
- Entrada nueva “Modo Wi-Fi · experimental” en la pantalla inicial y en Configuración.
- Cliente TCP con IP manual y puerto configurable (predeterminado 45820).
- Receptor TCP manual para ejecutar en el dispositivo receptor, mostrando IP, conexión y eventos recibidos.
- Envío de eventos JSON para botones (presionar/soltar) y ejes analógicos (LX/LY/RX/RY).
- Persistencia local de IP y puerto.
- El modo Bluetooth/HID existente se conserva en el código.

IMPORTANTE — LIMITACIÓN REAL:
Esta entrega implementa el transporte Wi-Fi y una prueba de recepción. El receptor registra eventos, pero NO inyecta eventos de mando al sistema Android ni garantiza que IGAMES PSP los reconozca como un mando físico. Para lograr eso hace falta una vía de entrada soportada por la TV Box/emulador, permisos privilegiados, o una integración específica. No anunciar como mando Wi-Fi terminado.

Prueba inicial cuando se genere el APK:
1. Instalar la misma APK en el teléfono y la TV Box.
2. En la TV Box, abrir “Receptor Wi-Fi en esta TV Box” y pulsar “Iniciar receptor”. Anotar IP y puerto.
3. En el teléfono, abrir “Modo Wi-Fi · experimental”, escribir la IP de la TV Box y conectar.
4. Abrir el mando y probar botones/sticks; los eventos deben aparecer en el registro del receptor.
5. Esta prueba valida solo transporte, no la entrada de juego en IGAMES PSP.

Estado de compilación: no compilado ni probado en dispositivo dentro de esta sesión.
