GAMEPAD ANDROID — VERSIÓN 0.11 (FUENTE)
Cambios respecto del ZIP v0.10:
- El servicio HidKeepAliveService solicita un PARTIAL_WAKE_LOCK mientras el servicio en primer plano está activo para reducir la posibilidad de que Android suspenda la CPU al apagar la pantalla.
- Se añadió el permiso WAKE_LOCK al AndroidManifest.xml.
- Se conserva la base del proyecto y la conexión Bluetooth HID existente; no se añadió USB.
Limitación importante:
Un WakeLock no garantiza que la conexión Bluetooth HID permanezca conectada. Android, el fabricante del teléfono, la implementación HID y la TV Box pueden cerrar la conexión. Debe probarse en el teléfono real.
Compilación:
Este ZIP contiene código fuente, no un APK compilado. La compilación debe comprobarse con GitHub Actions/Gradle.
