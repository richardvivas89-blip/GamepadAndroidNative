GAMEPAD ANDROID HID v22 — EDITOR POR GRUPOS Y SELECCIÓN CLARA

Cambios preparados a partir de los requisitos finales:
- La cruceta muestra solo arriba, abajo, izquierda y derecha; se elimina el control central visible.
- Las cuatro direcciones se mueven y cambian de tamaño como un conjunto.
- Triángulo, cuadrado, círculo y X se mueven y cambian de tamaño como conjunto, conservando proporciones.
- El grupo seleccionado se resalta en verde en modo edición.
- Los sticks se pueden seleccionar, mover y cambiar de tamaño.
- START y SELECT se ubican en la zona central, debajo de los sticks.
- Controles de tamaño más compactos y botón GUARDAR más legible.
- Se conservan los colores base y se mantienen fuera del editor las opciones innecesarias de elegir botón y color.
- Se conserva la lógica existente de conexión Bluetooth HID; validar en dispositivo real.

Pendiente de verificación: compilación mediante GitHub Actions y prueba física en TV Box.
