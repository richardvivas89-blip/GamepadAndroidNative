GAMEPAD ANDROID — VERSIÓN 25 (FUENTE EXPERIMENTAL)

Base: fuente v24 proporcionada por el usuario. Se conserva la implementación existente de Bluetooth HID y los controles personalizados.

Cambios v25:
- Incrementa versionCode de 10 a 11 y versionName a 1.0-wifi-v25 para distinguir la compilación experimental de v24.
- Mejora la selección de la dirección IPv4 mostrada por el receptor: prioriza interfaces que parecen ser Wi-Fi y omite direcciones loopback y link-local.
- Aclara en la pantalla del receptor que ambos dispositivos deben estar en la misma LAN y que el receptor TCP muestra mensajes de prueba; no inyecta por sí mismo entradas de mando en juegos de Android TV.
- Mantiene el puerto TCP 45820 y el protocolo de mensajes de texto JSON por línea existente.

IMPORTANTE — ESTADO Y LIMITACIONES:
- Esta entrega es la FUENTE ZIP; no es un APK ya compilado ni una prueba de funcionamiento en la TV Box.
- El envío Wi-Fi requiere que el receptor esté ejecutándose en un dispositivo compatible y que la red permita comunicación entre clientes. El receptor de esta app solo sirve para probar la conexión/protocolo.
- Para usar Wi-Fi como mando real en juegos de la TV Box, hace falta un receptor instalado en la TV Box que interprete los mensajes y los convierta en entradas utilizables, o una solución del sistema con los permisos adecuados. Este código no afirma que eso ya esté implementado.
- Bluetooth HID sigue siendo la vía prevista para que la TV Box reconozca el teléfono como dispositivo de entrada físico. No se ha podido probar el funcionamiento real en hardware desde este entorno.

Pruebas pendientes:
1. Importar GamepadAndroidNative_v2 en Android Studio/Gradle y compilar.
2. Instalar en un teléfono de prueba y verificar emparejamiento/registro Bluetooth HID.
3. Probar el receptor TCP con dos dispositivos en la misma Wi-Fi y comprobar los mensajes recibidos.
4. No reemplazar la v24 funcional hasta verificar la v25 en el dispositivo real.
