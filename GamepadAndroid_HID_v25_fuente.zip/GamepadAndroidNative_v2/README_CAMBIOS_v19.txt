GAMEPAD ANDROID HID v19 - CONFIGURACION LIMPIA Y EDITOR EN VIVO

Cambios sobre la fuente v17:
- En el mando normal se reemplaza la fila de acciones superior por un boton compacto de Configuracion.
- El panel Configuracion agrupa Editar mando, Pantalla completa, mantener conexion en segundo plano, volver a Bluetooth y salir.
- El editor conserva el fondo rojo, la seleccion de control, cambios de tamano/color y vista previa sobre el mando.
- Los sticks pueden arrastrarse en modo edicion y guardan su posicion.
- Se aumenta el tamano de texto de los botones y se reducen margenes para aprovechar espacio.

Nota: la compilacion debe confirmarse con GitHub Actions y probarse en el telefono. El arrastre grupal del D-pad completo aun requiere validacion/ajuste en dispositivo.
