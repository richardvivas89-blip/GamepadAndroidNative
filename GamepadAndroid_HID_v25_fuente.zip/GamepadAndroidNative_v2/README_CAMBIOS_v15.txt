GAMEPAD ANDROID HID v0.15 - edición en vivo
- Al elegir MODIFICAR BOTONES DEL PAD en pantalla 2, entra directamente al mando en modo configuración.
- Modo edición usa fondo rojo oscuro, estado rojo y bordes rojos para diferenciarlo claramente del modo normal.
- Los cambios de tamaño/color/posición hechos desde el panel de edición se reflejan al reconstruir el mando mientras sigue en modo edición.
- Arrastrar botones guarda la posición al soltar.
- Guardar y salir vuelve al tema azul normal.
- Sin USB.
Nota: verificar compilación y pruebas en dispositivo; no se garantiza arrastre suave para todos los controles/layouts.
