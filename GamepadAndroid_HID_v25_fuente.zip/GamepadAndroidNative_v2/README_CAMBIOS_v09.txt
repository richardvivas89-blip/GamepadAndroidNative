GAMEPAD ANDROID v0.10 - CONFIGURACIÓN Y SERVICIO EN SEGUNDO PLANO

Cambios sobre la fuente v0.9:
- Pantalla 2 de configuración más clara, mantiene los ajustes de tamaño y sensibilidad y el guardado automático.
- Botón en la pantalla del mando para solicitar el servicio en primer plano.
- Servicio con notificación persistente y tipo connectedDevice.
- APAGAR Y SALIR detiene el servicio y solicita desregistrar HID.
- onDestroy ya no anula automáticamente el registro HID al destruirse la Activity.

IMPORTANTE: el servicio mantiene un proceso visible, pero no es una garantía de conexión HID. La API BluetoothHidDevice y su callback siguen vinculados a la implementación de la Activity y el fabricante puede terminar el registro. Este código fuente no se compiló ni probó en hardware en esta sesión. Es necesario compilar en GitHub Actions y probar bloqueo/desbloqueo en el Motorola y la TV Box.
