GAMEPAD ANDROID - base v22 con ajustes añadidos

Cambios de código incluidos en esta entrega:
- Menú independiente “Sensibilidad y respuesta”.
- Ajuste persistente de intensidad de sticks (25-200%).
- Ajuste persistente de zona muerta de sticks (0-40%).
- Inversión persistente de eje vertical para cada stick.
- Tiempo mínimo configurable para pulsaciones digitales (0-150 ms).
- Menú de asignación que permite reasignar entradas digitales a salidas HID estándar o dejarlas sin asignar.
- El botón “Volver a Bluetooth” ahora intenta iniciar de nuevo el registro/selección HID tras volver a la pantalla Bluetooth.
- Versión incrementada a 1.0-custom-controls.

Limitaciones importantes:
- Este código aún debe compilarse y probarse en un dispositivo real. La reconexión HID depende también de la versión de Android y del receptor.
- Las asignaciones configurables se aplican a entradas digitales; la reasignación de los ejes analógicos a otras funciones no está implementada en esta entrega.
- El editor conserva el sistema de edición existente de la base v22; no se garantiza movimiento libre por toda la pantalla fuera de los límites de los contenedores actuales.
