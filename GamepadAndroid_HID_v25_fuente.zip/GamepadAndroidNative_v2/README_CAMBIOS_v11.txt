GAMEPAD ANDROID HID v0.11 - CAMBIOS

Cambios realizados en esta revisión:
- En la pantalla de configuración hay accesos separados: IR AL GAMEPAD VIRTUAL y MODIFICAR BOTONES DEL PAD.
- Se añadió un editor con ajustes de tamaño por función y selección cíclica de color del anillo por función, conservando las etiquetas originales.
- Se añadieron acciones para guardar/cargar un perfil básico en las preferencias locales.
- Se conserva el proyecto Bluetooth HID y el servicio de primer plano existente.
- No se agregó conexión USB.

Limitaciones conocidas:
- No se pudo ejecutar una compilación Gradle en este entorno porque Gradle no está instalado y no hay compilación Android verificada.
- El editor todavía no permite arrastrar libremente los controles ni mover grupos enteros como conjunto; los cambios de tamaño/color se aplican al reconstruir el mando.
- La persistencia del perfil cubre tamaño/sensibilidad básicos; los valores individuales se conservan en preferencias locales, pero guardar/cargar perfiles múltiples con nombres aún no está implementado.
- Mantener el proceso activo no garantiza que todos los dispositivos Android mantengan Bluetooth HID al bloquearse. Debe probarse en el teléfono y TV Box reales.
