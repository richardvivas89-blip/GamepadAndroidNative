GAMEPAD ANDROID HID v16 - REDISEÑO INICIAL DEL EDITOR

Cambios incluidos:
- Pantalla 2 simplificada: acceso al mando, editor, perfil y conexión.
- Tema rojo durante el modo de edición y tema azul oscuro en el modo normal.
- Editor con controles individuales para tamaño, color y ajuste de posición.
- Mantiene la estructura Android, el servicio HID y la lógica existente del proyecto.

Nota: la edición táctil directa y la incorporación libre de nuevos controles aún requieren validación y desarrollo adicional. Este ZIP no debe considerarse compilado/probado hasta ejecutar el workflow de GitHub Actions.
