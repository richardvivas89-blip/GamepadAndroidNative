GAMEPAD ANDROID HID v0.13 — PSP
- Añadida pantalla Configuración avanzada PSP.
- Se puede alternar entre diseño PSP (círculo, cruz, cuadrado, triángulo y hombros L/R) y diseño estándar.
- Los símbolos PSP se traducen a las teclas HID existentes: círculo=B, cruz=A, cuadrado=X, triángulo=Y, L=L1, R=R1; L2/R2 se mantienen.
- Se muestra tabla de asignaciones estándar y opción para restablecer cada una.
- Sin USB. Se conserva la conexión HID del proyecto base.
NOTA: esta pantalla gestiona diseño y asignaciones predeterminadas; no captura automáticamente eventos de entrada externos como hace un emulador PSP. Debe compilarse y probarse en GitHub Actions.
