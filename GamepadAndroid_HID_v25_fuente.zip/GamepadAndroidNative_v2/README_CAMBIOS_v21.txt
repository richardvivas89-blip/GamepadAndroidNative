GAMEPAD ANDROID HID v21 — EDITOR SIMPLIFICADO

Cambios:
- Eliminadas las funciones de elegir botón y cambiar colores.
- El editor conserva los colores predeterminados del mando.
- Los sticks centrales muestran contorno rojo en modo edición.
- Al tocar un control en modo edición queda seleccionado para ajustar tamaño cuando corresponda.
- Movimiento en grupo de cruceta y botones ABXY; desplazamientos limitados al área de su contenedor para reducir controles ocultos.
- Botón de configuración más grande y desplazado hacia la izquierda.
- Se conserva la implementación existente de Bluetooth HID.

La compilación y el funcionamiento en TV Box deben verificarse con GitHub Actions y dispositivo real.
