package com.example.gamepadandroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Servicio visible que pide a Android mantener vivo el proceso durante el uso del mando. */
class HidKeepAliveService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    override fun onCreate() {
        super.onCreate()
        // Mantiene CPU activa cuando la pantalla se apaga. No puede impedir que Android
        // o el dispositivo remoto decidan cerrar la conexión Bluetooth HID.
        try {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GamepadAndroid::HidKeepAlive")
            wakeLock?.setReferenceCounted(false)
            if (wakeLock?.isHeld != true) wakeLock?.acquire()
        } catch (_: Exception) { }
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Gamepad Android", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Mantiene activo el servicio de la aplicación mientras se usa el mando"
                }
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }.setSmallIcon(R.drawable.ic_gamepad)
            .setContentTitle("Gamepad Android activo")
            .setContentText("Servicio en segundo plano solicitado; la conexión HID depende de Android y del dispositivo")
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "gamepad_keep_alive"
        private const val NOTIFICATION_ID = 9021
    }
}
