GAMEPAD ANDROID HID v20 — correcciones del editor

Cambios:
- La cruceta D-PAD (arriba, abajo, izquierda, derecha y centro) se arrastra como conjunto.
- Los botones de acción (triángulo/círculo/cuadrado/X) se arrastran como conjunto para mantener su disposición.
- Los sticks conservan su modo de arrastre individual.
- Se desactiva el recorte de contenido en las vistas contenedoras para reducir controles cortados al arrastrar.
- Se aumenta la legibilidad de las etiquetas y títulos D-PAD/BOTONES.
- Se mantiene el código de comunicación Bluetooth HID del proyecto de origen.

Nota: probar en el dispositivo real; el recorte por los límites físicos de pantalla y la escala pueden variar según la TV Box.
