GAMEPAD ANDROID HID v17 - EDITOR DIRECTO
- El editor abre sobre la pantalla real del mando, con tema rojo.
- Se elimina la lista larga de filas de controles.
- Barra compacta para seleccionar botón, cambiar tamaño/color y guardar/cancelar.
- Cambios de tamaño/color vuelven a dibujar el mando para mostrar vista previa inmediata.
- El modo normal mantiene el tema azul.
- Basado en el proyecto v16; compilar y probar en el dispositivo antes de distribuir.
