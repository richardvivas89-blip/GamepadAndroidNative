GAMEPAD ANDROID HID v0.12 - ajustes solicitados
- Se quitó el control global de tamaño de la pantalla 2.
- La pantalla de edición incluye ajustes separados por botón: tamaño, color y desplazamiento horizontal/vertical.
- Las posiciones guardadas se aplican como desplazamientos visuales individuales al mando.
- El mando activa modo inmersivo de pantalla completa y tiene una acción para volver a activarlo.
- No se añadió USB.
Nota: el desplazamiento por controles se ajusta con las flechas del editor; no es arrastre táctil libre. Verificar compilación y probar en el dispositivo.
