GAMEPAD ANDROID HID v0.14
- Pantalla 2: retirados los controles deslizantes de tamaño y sensibilidad; quedan las opciones principales en botones.
- Gamepad: botón EDITAR que abre controles de edición compactos.
- Editor: selección de botón, tamaño +/-, color por ciclo y desplazamientos.
- Arrastre: el editor permite activar modo arrastre y guardar posición individual al soltar el botón.
- Pantalla completa y funciones PSP conservadas.
NOTA: ZIP de fuente generado, no se ha compilado en este entorno. Verificar con GitHub Actions y probar la interacción de arrastre en dispositivo.
