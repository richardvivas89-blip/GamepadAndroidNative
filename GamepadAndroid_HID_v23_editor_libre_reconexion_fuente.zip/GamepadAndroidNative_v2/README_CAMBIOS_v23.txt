GAMEPAD ANDROID HID v23 (basada en la fuente v22 corregida)

Cambios incluidos:
- Editor más compacto: menos padding y barra superior más baja.
- Movimiento de controles con límites basados en la pantalla completa y no en el pequeño contenedor original; grupos mantienen sus distancias.
- Botón de reconexión Bluetooth renombrado para dejar clara la acción.
- Al elegir «Volver a Bluetooth» no se desregistra ni se cierra el perfil HID, para permitir iniciar nuevamente el flujo de conexión sin reiniciar la app.
- Se conserva el descriptor HID y el envío de reportes de la v22.

Nota: es necesario probar el emparejamiento/reconexión en el teléfono y TV Box concretos; la API Android HID puede variar según fabricante. Esta fuente no se presenta como compilada ni probada en hardware.
