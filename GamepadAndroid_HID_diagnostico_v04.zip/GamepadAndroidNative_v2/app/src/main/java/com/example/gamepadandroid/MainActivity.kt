package com.example.gamepadandroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothHidDevice
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Gamepad Android v0.2
 * Sender: Wi-Fi TCP or Bluetooth Classic RFCOMM SPP.
 * Receiver: TCP server on port 45820 for testing the real local-network protocol.
 * This does not emulate Bluetooth HID or inject input into unrelated TV apps.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var eventLog: TextView
    private var tcpSocket: Socket? = null
    private var tcpOut: OutputStream? = null
    private var btSocket: BluetoothSocket? = null
    private var btOut: OutputStream? = null
    private var serverSocket: ServerSocket? = null
    @Volatile private var receiverRunning = false
    private var transport = "none"
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var hidProfileAvailable = false
    private var hidProxy: BluetoothHidDevice? = null
    private val hidCallback = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE && proxy is BluetoothHidDevice) {
                hidProxy = proxy
                hidProfileAvailable = true
                runOnUiThread {
                    if (::status.isInitialized) status.text = "Perfil HID disponible en el teléfono. Aún falta registrar y probar el mando con el TV Box."
                }
            }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidProxy = null
                hidProfileAvailable = false
                runOnUiThread {
                    if (::status.isInitialized) status.text = "El servicio Bluetooth HID se desconectó."
                }
            }
        }
    }
    private val adapter: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        buildBluetoothUi()
        requestBluetoothPermissionsIfNeeded()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 24, 22, 20)
        setBackgroundColor(0xFF0B0E14.toInt())
    }

    private fun text(value: String, size: Float = 15f) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(0xFFEEF2F8.toInt())
        setPadding(0, 8, 0, 8)
    }


    /** Primera pantalla: emparejamiento/conexión Bluetooth antes de mostrar el mando. */
    private fun buildBluetoothUi(message: String = "Conectá el TV Box para continuar") {
        val root = baseLayout()
        root.gravity = Gravity.CENTER
        root.setPadding(28, 20, 28, 20)
        root.addView(text("GAMEPAD ANDROID", 28f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF43D9FF.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(text("PANTALLA 1 · CONEXIÓN BLUETOOTH", 17f).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        status = text(message, 15f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7DD.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(actionButton("BUSCAR DISPOSITIVOS EMPAREJADOS") { showBluetoothDevices() },
            LinearLayout.LayoutParams(-1, 54).apply { setMargins(30, 14, 30, 8) })
        root.addView(actionButton("COMPROBAR SOPORTE BLUETOOTH HID") { checkHidSupport() },
            LinearLayout.LayoutParams(-1, 50).apply { setMargins(30, 4, 30, 6) })
        root.addView(actionButton("ABRIR AJUSTES DE BLUETOOTH") {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
            catch (_: Exception) { status.text = "No se pudieron abrir los ajustes de Bluetooth." }
        }, LinearLayout.LayoutParams(-1, 48).apply { setMargins(30, 4, 30, 8) })
        root.addView(text("Esta versión comprueba si Android ofrece el perfil HID. La prueba no garantiza compatibilidad con el TV Box. RFCOMM/SPP no es un mando universal.", 12f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF8B9AB5.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun buildControllerUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(0xFF080D18.toInt())
        }
        status = text("GAMEPAD ANDROID  •  BLUETOOTH SIN CONECTAR", 14f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF43D9FF.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 36))

        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toolbar.addView(actionButton("VOLVER A BLUETOOTH") { disconnect(); buildBluetoothUi("Desconectado. Elegí el TV Box para volver a conectar.") }, LinearLayout.LayoutParams(0, 44, 1f))
        toolbar.addView(actionButton("DESCONECTAR") { disconnect(); buildBluetoothUi("Bluetooth desconectado.") }, LinearLayout.LayoutParams(0, 44, 1f))
        root.addView(toolbar)

        val board = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 0)
        }
        // Left grip: directional pad and shoulder controls.
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        left.addView(text("D-PAD", 11f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val dpad = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        listOf("" to "", "▲" to "UP", "" to "", "◀" to "LEFT", "●" to "CENTER", "▶" to "RIGHT", "" to "", "▼" to "DOWN", "" to "").forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            dpad.addView(b, GridLayout.LayoutParams().apply { width = 52; height = 45; setMargins(2, 2, 2, 2) })
        }
        left.addView(dpad)
        val shouldersL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("L1", "L2").forEach { shouldersL.addView(touchButton(it, it), LinearLayout.LayoutParams(66, 38).apply { setMargins(3, 3, 3, 3) }) }
        left.addView(shouldersL)
        board.addView(left, LinearLayout.LayoutParams(0, -1, 1f))

        // Center: twin touch sticks (visual controls; axis events are emitted as JSON).
        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        center.addView(StickView("LX", "LY"), LinearLayout.LayoutParams(0, 170, 1f).apply { setMargins(4, 0, 4, 0) })
        center.addView(StickView("RX", "RY"), LinearLayout.LayoutParams(0, 170, 1f).apply { setMargins(4, 0, 4, 0) })
        board.addView(center, LinearLayout.LayoutParams(0, -1, 2f))

        // Right grip: Xbox ABXY layout and system buttons.
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        right.addView(text("BOTONES", 11f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val xy = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        listOf("" to "", "Y" to "Y", "" to "", "X" to "X", "" to "", "B" to "B", "" to "", "A" to "A", "" to "").forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            if (key.isNotEmpty()) b.setTextColor(when (key) { "A" -> 0xFF47E58A.toInt(); "B" -> 0xFFFF647C.toInt(); "X" -> 0xFF48A9FF.toInt(); else -> 0xFFFFD34F.toInt() })
            xy.addView(b, GridLayout.LayoutParams().apply { width = 48; height = 43; setMargins(2, 2, 2, 2) })
        }
        right.addView(xy)
        val shouldersR = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("R1", "R2").forEach { shouldersR.addView(touchButton(it, it), LinearLayout.LayoutParams(66, 38).apply { setMargins(3, 3, 3, 3) }) }
        right.addView(shouldersR)
        val system = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("SELECT", "START").forEach { system.addView(touchButton(it, it), LinearLayout.LayoutParams(76, 34).apply { setMargins(3, 3, 3, 3) }) }
        right.addView(system)
        board.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Aviso: la conexión Bluetooth actual es RFCOMM/SPP; no equivale a un mando HID universal. Esta versión no garantiza control en juegos del TV Box.", 10f).apply {
            setTextColor(0xFF9AA8BF.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun touchButton(label: String, key: String): Button = actionButton(label) {}.apply {
        setBackgroundColor(0xFF202D43.toInt())
        setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { sendButton(key, true); v.isPressed = true; true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { sendButton(key, false); v.isPressed = false; true }
                else -> true
            }
        }
    }

    private inner class StickView(private val xAxis: String, private val yAxis: String) : View(this@MainActivity) {
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C2A40.toInt(); style = Paint.Style.FILL }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF43D9FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
        private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF324967.toInt(); style = Paint.Style.FILL }
        private var px = 0f; private var py = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val radius = (minOf(width, height) * .37f)
            canvas.drawCircle(cx, cy, radius, ring); canvas.drawCircle(cx, cy, radius, outline)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, knob)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, outline)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val radius = minOf(width, height) * .37f
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    px = ((event.x - width / 2f) / radius).coerceIn(-1f, 1f)
                    py = ((event.y - height / 2f) / radius).coerceIn(-1f, 1f)
                    sendRaw("{\"type\":\"axis\",\"x\":\"$xAxis\",\"value\":${"%.2f".format(java.util.Locale.US, px)}}")
                    sendRaw("{\"type\":\"axis\",\"x\":\"$yAxis\",\"value\":${"%.2f".format(java.util.Locale.US, py)}}")
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    px = 0f; py = 0f
                    sendRaw("{\"type\":\"axis\",\"x\":\"$xAxis\",\"value\":0.00}")
                    sendRaw("{\"type\":\"axis\",\"x\":\"$yAxis\",\"value\":0.00}")
                    invalidate(); return true
                }
            }
            return true
        }
    }

    private fun buildReceiverUi() {
        disconnect()
        val outer = baseLayout()
        outer.addView(text("RECEPTOR WI-FI · GAMEPAD ANDROID", 20f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF5EEAD4.toInt())
        }, matchWrap())
        val ip = localIpv4() ?: "No se detectó IP Wi-Fi"
        outer.addView(text("IP de este dispositivo: $ip\nPuerto TCP: 45820\nConectá el mando desde otro dispositivo usando esta IP."), matchWrap())
        status = text("Receptor detenido")
        outer.addView(status, matchWrap())
        outer.addView(actionButton("Iniciar receptor") { startReceiver() }, matchWrap())
        outer.addView(actionButton("Detener receptor") { stopReceiver() }, matchWrap())
        outer.addView(actionButton("Volver al mando") { stopReceiver(); buildControllerUi() }, matchWrap())
        outer.addView(text("Eventos recibidos:", 17f), matchWrap())
        eventLog = text("Todavía no llegaron eventos.")
        outer.addView(eventLog, matchWrap())
        setContentView(ScrollView(this).apply { addView(outer) })
    }

    private fun startReceiver() {
        if (receiverRunning) { status.text = "Receptor activo en puerto 45820"; return }
        receiverRunning = true
        status.text = "Iniciando receptor…"
        thread(name = "gamepad-wifi-receiver") {
            try {
                val server = ServerSocket()
                server.reuseAddress = true
                server.bind(InetSocketAddress(45820))
                serverSocket = server
                runOnUiThread { status.text = "Receptor activo · puerto 45820" }
                while (receiverRunning) {
                    val client = server.accept()
                    thread(name = "gamepad-client") { handleClient(client) }
                }
            } catch (e: Exception) {
                if (receiverRunning) runOnUiThread {
                    status.text = "No se pudo iniciar receptor: ${e.localizedMessage ?: "error"}"
                }
            } finally {
                receiverRunning = false
                try { serverSocket?.close() } catch (_: Exception) {}
                serverSocket = null
            }
        }
    }

    private fun handleClient(client: Socket) {
        val peer = client.inetAddress?.hostAddress ?: "cliente"
        runOnUiThread { appendEvent("Conectado: $peer") }
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            while (receiverRunning) {
                val line = reader.readLine() ?: break
                runOnUiThread { appendEvent(line) }
            }
        } catch (e: Exception) {
            runOnUiThread { appendEvent("Conexión cerrada: ${e.localizedMessage ?: "desconocida"}") }
        } finally {
            try { client.close() } catch (_: Exception) {}
            runOnUiThread { appendEvent("Desconectado: $peer") }
        }
    }

    private fun appendEvent(line: String) {
        if (!::eventLog.isInitialized) return
        val old = eventLog.text.toString()
        val lines = (if (old == "Todavía no llegaron eventos.") emptyList() else old.lines()) + line
        eventLog.text = lines.takeLast(35).joinToString("\n")
    }

    private fun stopReceiver() {
        receiverRunning = false
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        if (::status.isInitialized) status.text = "Receptor detenido"
    }

    private fun localIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(0xFFEEF2F8.toInt())
        setBackgroundColor(0xFF293347.toInt())
        setOnClickListener { click() }
    }

    private fun connectWifi() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().toIntOrNull() ?: 45820
        if (host.isBlank()) { status.text = "Escribí la IP del dispositivo receptor."; return }
        status.text = "Conectando por Wi-Fi…"
        thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 4000)
                val out = s.getOutputStream()
                try { tcpSocket?.close() } catch (_: Exception) {}
                tcpSocket = s; tcpOut = out; transport = "wifi"
                runOnUiThread { status.text = "Conectado por Wi-Fi · $host:$port" }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":2}")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Wi-Fi no conectado: ${e.localizedMessage ?: "error"}" }
            }
        }
    }

    /** Diagnóstico: comprueba si Android expone el perfil HID Device. No registra todavía un mando. */
    private fun checkHidSupport() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no dispone de Bluetooth."; return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "Bluetooth HID Device requiere Android 9 o posterior."; return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé el permiso Bluetooth y volvé a comprobar HID."; return
        }
        try {
            status.text = "Comprobando si Android ofrece Bluetooth HID…"
            val requested = a.getProfileProxy(this, hidCallback, BluetoothProfile.HID_DEVICE)
            if (!requested) {
                status.text = "Android no pudo abrir el perfil HID Device en este teléfono. No se modificó el emparejamiento."
            } else {
                status.text = "Solicitud HID enviada. Esperá unos segundos; el resultado aparecerá aquí."
            }
        } catch (e: SecurityException) {
            status.text = "Permiso Bluetooth insuficiente para comprobar HID."
        } catch (e: Exception) {
            status.text = "No se pudo comprobar HID: ${e.localizedMessage ?: "error del sistema"}"
        }
    }

    private fun showBluetoothDevices() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no tiene Bluetooth."; return }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé permiso Bluetooth y volvé a intentarlo."
            return
        }
        if (!a.isEnabled) { status.text = "Activá Bluetooth en Ajustes y volvé a intentarlo."; return }
        try {
            val devices = a.bondedDevices.toList()
            if (devices.isEmpty()) {
                status.text = "No hay dispositivos emparejados. Emparejá primero el receptor en Ajustes."
                return
            }
            val labels = devices.map { "${it.name ?: "Dispositivo"} · ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Elegí un receptor Bluetooth")
                .setItems(labels) { _, which -> connectBluetooth(devices[which]) }
                .setNegativeButton("Cancelar", null).show()
        } catch (_: SecurityException) { status.text = "Permiso Bluetooth denegado." }
    }

    private fun connectBluetooth(device: BluetoothDevice) {
        status.text = "Conectando Bluetooth…"
        thread {
            try {
                adapter?.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                try { btSocket?.close() } catch (_: Exception) {}
                btSocket = socket; btOut = socket.outputStream; transport = "bluetooth"
                runOnUiThread {
                    status.text = "Bluetooth RFCOMM conectado · ${device.name ?: device.address}"
                    buildControllerUi()
                }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":3}")
            } catch (e: Exception) {
                runOnUiThread { buildBluetoothUi("Bluetooth no conectado: ${e.localizedMessage ?: "error"}. Revisá que el TV Box admita RFCOMM/SPP.") }
            }
        }
    }

    private fun sendButton(name: String, down: Boolean) {
        sendRaw("{\"type\":\"button\",\"name\":\"$name\",\"down\":$down}")
        if (down && ::status.isInitialized) status.text = "Entrada: $name"
    }

    private fun sendRaw(message: String) {
        val bytes = (message + "\n").toByteArray(Charsets.UTF_8)
        thread {
            try {
                when (transport) {
                    "wifi" -> synchronized(this) { tcpOut?.write(bytes); tcpOut?.flush() }
                    "bluetooth" -> synchronized(this) { btOut?.write(bytes); btOut?.flush() }
                    else -> { /* Offline preview: no remote transport. */ }
                }
            } catch (e: Exception) {
                runOnUiThread { if (::status.isInitialized) status.text = "Error enviando datos: ${e.localizedMessage ?: "conexión perdida"}" }
            }
        }
    }

    private fun disconnect() {
        transport = "none"
        try { tcpOut?.close() } catch (_: Exception) {}
        try { tcpSocket?.close() } catch (_: Exception) {}
        try { btOut?.close() } catch (_: Exception) {}
        try { btSocket?.close() } catch (_: Exception) {}
        tcpOut = null; tcpSocket = null; btOut = null; btSocket = null
    }

    private fun requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val missing = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 101)
        }
    }

    override fun onDestroy() {
        stopReceiver()
        disconnect()
        try { hidProxy?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (_: Exception) {}
        hidProxy = null
        super.onDestroy()
    }
}
