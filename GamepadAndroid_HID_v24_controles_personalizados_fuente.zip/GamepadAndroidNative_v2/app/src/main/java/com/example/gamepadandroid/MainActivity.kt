package com.example.gamepadandroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Gamepad Android v0.2
 * Sender: Wi-Fi TCP or Bluetooth Classic RFCOMM SPP.
 * Receiver: TCP server on port 45820 for testing the real local-network protocol.
 * This does not emulate Bluetooth HID or inject input into unrelated TV apps.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var eventLog: TextView
    private var tcpSocket: Socket? = null
    private var tcpOut: OutputStream? = null
    private var btSocket: BluetoothSocket? = null
    private var btOut: OutputStream? = null
    private var serverSocket: ServerSocket? = null
    @Volatile private var receiverRunning = false
    private var transport = "none"
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var hidProfileAvailable = false
    private var hidRegistered = false
    private var hidTarget: BluetoothDevice? = null
    private val hidExecutor: Executor = Executors.newSingleThreadExecutor()
    private val heldButtons = mutableSetOf<String>()
    // Vistas registradas para que los controles que forman un conjunto se arrastren juntos.
    private val editableButtonViews = linkedMapOf<String, View>()
    private val buttonGroups = mapOf(
        "UP" to listOf("UP", "DOWN", "LEFT", "RIGHT"),
        "DOWN" to listOf("UP", "DOWN", "LEFT", "RIGHT"),
        "LEFT" to listOf("UP", "DOWN", "LEFT", "RIGHT"),
        "RIGHT" to listOf("UP", "DOWN", "LEFT", "RIGHT"),
        "A" to listOf("A", "B", "X", "Y"),
        "B" to listOf("A", "B", "X", "Y"),
        "X" to listOf("A", "B", "X", "Y"),
        "Y" to listOf("A", "B", "X", "Y")
    )
    private var axisLX = 0; private var axisLY = 0
    private var axisRX = 0; private var axisRY = 0
    private var hidProxy: BluetoothHidDevice? = null
    private val hidDeviceCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            hidRegistered = registered
            runOnUiThread {
                if (::status.isInitialized) status.text =
                    if (registered) "Mando HID registrado. Seleccioná el teléfono en la TV Box y conectá."
                    else "El registro HID no está activo. Mantené la aplicación abierta."
            }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            runOnUiThread {
                if (device != null && state == BluetoothProfile.STATE_CONNECTED) {
                    hidTarget = device
                    status.text = "Mando HID conectado · ${device.name ?: "TV Box"}"
                    buildSettingsUi()
                } else if (device != null && state == BluetoothProfile.STATE_DISCONNECTED) {
                    if (::status.isInitialized) status.text = "Mando HID desconectado de ${device.name ?: "TV Box"}."
                }
            }
        }
    }
    private val hidCallback = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HID_DEVICE && proxy is BluetoothHidDevice) {
                hidProxy = proxy
                hidProfileAvailable = true
                runOnUiThread {
                    if (::status.isInitialized) status.text = "Perfil HID disponible. Elegí el TV Box para registrar el mando."
                }
            }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidProxy = null
                hidProfileAvailable = false
                runOnUiThread {
                    if (::status.isInitialized) status.text = "El servicio Bluetooth HID se desconectó."
                }
            }
        }
    }
    private val adapter: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()

    private fun setImmersiveFullscreen(enabled: Boolean) {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (enabled) (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        ) else View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        buildBluetoothUi()
        requestBluetoothPermissionsIfNeeded()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 24, 22, 20)
        setBackgroundColor(0xFF0B0E14.toInt())
    }

    private fun text(value: String, size: Float = 15f) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(0xFFEEF2F8.toInt())
        includeFontPadding = true
        setPadding(4, 6, 4, 6)
    }


    /** Primera pantalla: emparejamiento/conexión Bluetooth antes de mostrar el mando. */
    private fun buildBluetoothUi(message: String = "Conectá el TV Box para continuar") {
        setImmersiveFullscreen(false)
        val root = baseLayout()
        root.gravity = Gravity.CENTER
        root.setPadding(24, 12, 24, 12)
        root.addView(text("🎮  GAMEPAD ANDROID", 29f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF43D9FF.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(text("PANTALLA 1 · CONEXIÓN BLUETOOTH", 17f).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        status = text(message, 15f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7DD.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(actionButton("CONECTAR Y REGISTRAR MANDO") { startHidRegistrationAndSelectHost() },
            LinearLayout.LayoutParams(-1, 52).apply { setMargins(30, 10, 30, 6) })
        root.addView(actionButton("COMPROBAR SOPORTE BLUETOOTH HID") { checkHidSupport() },
            LinearLayout.LayoutParams(-1, 48).apply { setMargins(30, 4, 30, 6) })
        root.addView(actionButton("ABRIR AJUSTES DE BLUETOOTH") {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
            catch (_: Exception) { status.text = "No se pudieron abrir los ajustes de Bluetooth." }
        }, LinearLayout.LayoutParams(-1, 48).apply { setMargins(30, 4, 30, 8) })
        root.addView(text("Esta versión intenta registrar un mando HID real. La compatibilidad depende del Android y de la TV Box.", 12f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF8B9AB5.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private val prefs by lazy { getSharedPreferences("gamepad_settings", MODE_PRIVATE) }
    private fun buttonSize(): Int = prefs.getInt("button_size", 52).coerceIn(40, 88)
    private fun sensitivity(): Float = prefs.getInt("sensitivity", 100).coerceIn(25, 200) / 100f

    /** Pantalla 2 simplificada: conexión y acceso al mando/editor. */
    private fun buildSettingsUi() {
        editMode = false
        setImmersiveFullscreen(false)
        val root = baseLayout()
        root.setBackgroundColor(0xFF080D18.toInt())
        root.addView(text("GAMEPAD ANDROID", 28f).apply { gravity = Gravity.CENTER; setTextColor(0xFF22A8FF.toInt()) }, matchWrap())
        root.addView(text("CONFIGURACIÓN DEL MANDO", 17f).apply { gravity = Gravity.CENTER }, matchWrap())
        root.addView(text("Conectá el dispositivo y personalizá el mando desde la vista previa.", 13f), matchWrap())
        root.addView(actionButton("IR AL GAMEPAD VIRTUAL") { buildControllerUi() }, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 14, 0, 6) })
        root.addView(actionButton("MODIFICAR BOTONES DEL PAD") { buildEditorUi() }, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 4, 0, 6) })
        root.addView(actionButton("GUARDAR PERFIL") {
            prefs.edit().putInt("profile_button_size", buttonSize()).putInt("profile_sensitivity", (sensitivity()*100).toInt()).apply()
            Toast.makeText(this, "Perfil guardado en este teléfono", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, 48).apply { setMargins(0, 4, 0, 6) })
        root.addView(actionButton("VOLVER A CONEXIÓN") { buildBluetoothUi() }, matchWrap())
        setContentView(root)
    }

    /** Menú independiente para la respuesta táctil y la sensibilidad de los sticks. */
    private fun buildSensitivityUi() {
        setImmersiveFullscreen(false)
        val root = baseLayout()
        root.addView(text("SENSIBILIDAD Y RESPUESTA", 22f).apply { gravity = Gravity.CENTER; setTextColor(0xFF43D9FF.toInt()) }, matchWrap())
        root.addView(text("Estos ajustes se guardan en este teléfono.", 13f), matchWrap())
        fun addSlider(label: String, key: String, min: Int, max: Int, initial: Int, suffix: String = "") {
            root.addView(text("$label: ${prefs.getInt(key, initial)}$suffix", 15f), matchWrap())
            val valueLabel = root.getChildAt(root.childCount - 1) as TextView
            val bar = SeekBar(this).apply { this.max = max - min; progress = (prefs.getInt(key, initial).coerceIn(min, max) - min) }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + progress
                    valueLabel.text = "$label: $value$suffix"
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            root.addView(bar, matchWrap())
        }
        addSlider("Intensidad de los sticks", "sensitivity", 25, 200, 100, "%")
        addSlider("Zona muerta de los sticks", "dead_zone", 0, 40, 8, "%")
        addSlider("Tiempo mínimo de pulsación digital", "button_press_ms", 0, 150, 0, " ms")
        root.addView(actionButton("Invertir eje vertical izquierdo") {
            prefs.edit().putBoolean("invert_ly", !prefs.getBoolean("invert_ly", false)).apply()
            Toast.makeText(this, if (prefs.getBoolean("invert_ly", false)) "Eje vertical izquierdo invertido" else "Eje vertical izquierdo normal", Toast.LENGTH_SHORT).show()
        }, matchWrap())
        root.addView(actionButton("Invertir eje vertical derecho") {
            prefs.edit().putBoolean("invert_ry", !prefs.getBoolean("invert_ry", false)).apply()
            Toast.makeText(this, if (prefs.getBoolean("invert_ry", false)) "Eje vertical derecho invertido" else "Eje vertical derecho normal", Toast.LENGTH_SHORT).show()
        }, matchWrap())
        root.addView(actionButton("Restablecer sensibilidad") {
            prefs.edit().putInt("sensitivity", 100).putInt("dead_zone", 8).putInt("button_press_ms", 0).putBoolean("invert_ly", false).putBoolean("invert_ry", false).apply()
            buildSensitivityUi()
        }, matchWrap())
        root.addView(actionButton("Volver a configuración") { buildSettingsUi() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** Configuración de etiquetas y asignaciones estilo PSP. Los códigos enviados siguen siendo HID estándar. */
    private fun buildPspMappingUi() {
        setImmersiveFullscreen(false)
        val root = baseLayout()
        root.addView(text("CONFIGURACIÓN AVANZADA PSP", 22f).apply { gravity = Gravity.CENTER; setTextColor(0xFF43D9FF.toInt()) }, matchWrap())
        root.addView(text("Elegí el diseño PSP o el diseño estándar. Las funciones PSP se traducen a botones HID estándar para maximizar compatibilidad.", 13f), matchWrap())
        val psp = prefs.getBoolean("psp_layout", true)
        root.addView(actionButton(if (psp) "MODO ACTUAL: PSP · TOCAR PARA USAR ESTÁNDAR" else "MODO ACTUAL: ESTÁNDAR · TOCAR PARA USAR PSP") {
            prefs.edit().putBoolean("psp_layout", !prefs.getBoolean("psp_layout", true)).apply()
            buildPspMappingUi()
        }, LinearLayout.LayoutParams(-1, 52).apply { setMargins(0, 10, 0, 10) })
        root.addView(text("ASIGNACIONES PSP", 16f).apply { setTextColor(0xFF43D9FF.toInt()) }, matchWrap())
        val mappingRows = listOf("Arriba" to "UP", "Abajo" to "DOWN", "Izquierda" to "LEFT", "Derecha" to "RIGHT", "Círculo (○)" to "B", "Cruz (×)" to "A", "Cuadrado (□)" to "X", "Triángulo (△)" to "Y", "L" to "L1", "R" to "R1", "L2" to "L2", "R2" to "R2", "START" to "START", "SELECT" to "SELECT")
        mappingRows.forEach { (label, key) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(label, 14f), LinearLayout.LayoutParams(0, 42, 1f))
            val outputKey = "mapping_$key"
            val current = prefs.getString(outputKey, key) ?: key
            row.addView(actionButton("→ $current") {
                val outputs = arrayOf("A", "B", "X", "Y", "L1", "R1", "L2", "R2", "SELECT", "START", "UP", "DOWN", "LEFT", "RIGHT", "SIN ASIGNAR")
                AlertDialog.Builder(this).setTitle("Función para $label").setItems(outputs) { _, index ->
                    val chosen = if (index == outputs.lastIndex) "" else outputs[index]
                    prefs.edit().putString(outputKey, chosen).apply()
                    buildPspMappingUi()
                }.show()
            }, LinearLayout.LayoutParams(0, 42, 1f))
            row.addView(actionButton("RESTABLECER") { prefs.edit().remove(outputKey).apply(); buildPspMappingUi() }, LinearLayout.LayoutParams(0, 42, 1f))
            root.addView(row)
        }
        root.addView(actionButton("VOLVER AL MENÚ") { buildSettingsUi() }, matchWrap())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** El editor ahora usa el propio mando como superficie de edición: los cambios se ven sobre él. */
    private fun buildEditorUi() {
        editMode = true
        selectedEditKey = "A"
        buildControllerUi()
    }

    private var editMode = false
    private var selectedEditKey = "A"

    private fun changeSelectedSize(delta: Int) {
        val group = buttonGroups[selectedEditKey] ?: listOf(selectedEditKey)
        val editor = prefs.edit()
        group.distinct().forEach { key ->
            val prefKey = "size_$key"
            val defaultSize = if (key.startsWith("STICK_")) 150 else buttonSize()
            editor.putInt(prefKey, (prefs.getInt(prefKey, defaultSize) + delta).coerceIn(36, 180))
        }
        editor.apply()
        buildControllerUi()
    }

    private fun translationLimit(view: View, horizontal: Boolean): Float {
        val parent = view.parent as? View ?: return 120f
        val extent = if (horizontal) parent.width else parent.height
        val childExtent = if (horizontal) view.width else view.height
        return ((extent - childExtent) / 2f).coerceAtLeast(0f)
    }

    private fun clampTranslation(view: View, value: Float, horizontal: Boolean): Float {
        val limit = translationLimit(view, horizontal)
        return value.coerceIn(-limit, limit)
    }

    /** Limita el desplazamiento común para que todos los miembros mantengan su posición relativa. */
    private fun moveGroupTogether(keys: List<String>, dx: Float, dy: Float) {
        val members = keys.mapNotNull { editableButtonViews[it] }
        if (members.isEmpty()) return
        var minDx = Float.NEGATIVE_INFINITY
        var maxDx = Float.POSITIVE_INFINITY
        var minDy = Float.NEGATIVE_INFINITY
        var maxDy = Float.POSITIVE_INFINITY
        members.forEach { member ->
            val lx = translationLimit(member, true)
            val ly = translationLimit(member, false)
            minDx = maxOf(minDx, -lx - member.translationX)
            maxDx = minOf(maxDx, lx - member.translationX)
            minDy = maxOf(minDy, -ly - member.translationY)
            maxDy = minOf(maxDy, ly - member.translationY)
        }
        val safeDx = if (minDx <= maxDx) dx.coerceIn(minDx, maxDx) else 0f
        val safeDy = if (minDy <= maxDy) dy.coerceIn(minDy, maxDy) else 0f
        members.forEach { it.translationX += safeDx; it.translationY += safeDy }
    }

    private fun showControllerSettings() {
        val choices = arrayOf("Editar mando", "Sensibilidad y respuesta", "Asignar funciones", "Pantalla completa", "Mantener conexión Bluetooth en segundo plano", "Volver a Bluetooth", "Apagar y salir")
        AlertDialog.Builder(this)
            .setTitle("Configuración")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> buildEditorUi()
                    1 -> buildSensitivityUi()
                    2 -> buildPspMappingUi()
                    3 -> { setImmersiveFullscreen(true); Toast.makeText(this, "Pantalla completa activada", Toast.LENGTH_SHORT).show() }
                    4 -> try {
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, HidKeepAliveService::class.java)) else startService(Intent(this, HidKeepAliveService::class.java))
                        Toast.makeText(this, "Servicio en segundo plano activado", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) { Toast.makeText(this, "No se pudo iniciar: ${e.localizedMessage ?: "error"}", Toast.LENGTH_LONG).show() }
                    5 -> {
                        disconnect()
                        buildBluetoothUi("Preparando reconexión Bluetooth…")
                        startHidRegistrationAndSelectHost()
                    }
                    6 -> { disconnect(); try { hidProxy?.unregisterApp() } catch (_: Exception) {}; stopService(Intent(this, HidKeepAliveService::class.java)); finishAffinity() }
                }
            }.setNegativeButton("Cerrar", null).show()
    }

    private fun buildControllerUi() {
        editableButtonViews.clear()
        setImmersiveFullscreen(true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(8, 4, 8, 4)
            setBackgroundColor(if (editMode) 0xFF18070B.toInt() else 0xFF080D18.toInt())
        }
        status = text(if (editMode) "MODO EDICIÓN ROJO · Seleccionado: $selectedEditKey · Arrastrá los botones" else "GAMEPAD ANDROID  •  BLUETOOTH SIN CONECTAR", 14f).apply {
            gravity = Gravity.CENTER
            setTextColor(if (editMode) 0xFFFF4058.toInt() else 0xFF43D9FF.toInt())
        }
        if (editMode) {
            root.addView(status, LinearLayout.LayoutParams(-1, 28))
            val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            toolbar.addView(actionButton("−") { changeSelectedSize(-4) }, LinearLayout.LayoutParams(0, 34, .35f))
            toolbar.addView(actionButton("+") { changeSelectedSize(4) }, LinearLayout.LayoutParams(0, 34, .35f))
            toolbar.addView(actionButton("GUARDAR") {
                prefs.edit().putBoolean("custom_profile_saved", true).apply()
                editMode = false
                buildControllerUi()
            }, LinearLayout.LayoutParams(0, 40, 1.2f))
            toolbar.addView(actionButton("✕") { editMode = false; buildControllerUi() }, LinearLayout.LayoutParams(0, 40, .55f))
            root.addView(toolbar)
        } else {
            // One small settings entry keeps the play surface clear.
            val top = FrameLayout(this)
            top.addView(status, FrameLayout.LayoutParams(-1, 24, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            val gear = actionButton("⚙") { showControllerSettings() }.apply { textSize = 25f; contentDescription = "Configuración" }
            top.addView(gear, FrameLayout.LayoutParams(60, 48, Gravity.TOP or Gravity.END).apply { rightMargin = 18 })
            root.addView(top, LinearLayout.LayoutParams(-1, 44))
        }

        val board = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
            clipChildren = false
            clipToPadding = false
            setPadding(0, 8, 0, 0)
        }
        // Left grip: directional pad and shoulder controls.
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        left.addView(text("D-PAD", 14f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val dpad = GridLayout(this).apply { columnCount = 3; rowCount = 3; clipChildren = false; clipToPadding = false }
        listOf("" to "", "▲" to "UP", "" to "", "◀" to "LEFT", "" to "", "▶" to "RIGHT", "" to "", "▼" to "DOWN", "" to "").forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            dpad.addView(b, GridLayout.LayoutParams().apply { width = prefs.getInt("size_$key", buttonSize()) + 8; height = prefs.getInt("size_$key", buttonSize()); setMargins(4, 4, 4, 4) })
        }
        left.addView(dpad)
        val shouldersL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf((if (prefs.getBoolean("psp_layout", true)) "L" else "L1") to "L1", "L2" to "L2").forEach { (label, key) -> shouldersL.addView(touchButton(label, key), LinearLayout.LayoutParams(76, 44).apply { setMargins(4, 4, 4, 4) }) }
        left.addView(shouldersL)
        board.addView(left, LinearLayout.LayoutParams(0, -1, 1f))

        // Center: twin touch sticks; movement is sent as HID axis reports.
        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        fun editableStick(axisX: String, axisY: String, key: String): View {
            val stick = StickView(axisX, axisY, key).apply {
                val stickSize = prefs.getInt("size_$key", 150).coerceIn(90, 180)
                layoutParams = LinearLayout.LayoutParams(stickSize, stickSize)
            }
            editableButtonViews[key] = stick
            stick.translationX = prefs.getInt("pos_x_$key", 0).toFloat()
            stick.translationY = prefs.getInt("pos_y_$key", 0).toFloat()
            var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f
            stick.setOnTouchListener { v, e ->
                if (!editMode) return@setOnTouchListener false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        selectedEditKey = key
                        status.text = "MODO EDICIÓN · Seleccionado: $selectedEditKey · Arrastrá para mover"
                        v.invalidate()
                        downX=e.rawX; downY=e.rawY; startX=v.translationX; startY=v.translationY; true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        v.translationX = clampTranslation(v, startX + e.rawX - downX, true)
                        v.translationY = clampTranslation(v, startY + e.rawY - downY, false)
                        refreshEditHighlights()
                        v.invalidate(); true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { prefs.edit().putInt("pos_x_$key",v.translationX.toInt()).putInt("pos_y_$key",v.translationY.toInt()).apply(); true }
                    else -> true
                }
            }
            return stick
        }
        val centerColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        center.addView(editableStick("LX", "LY", "STICK_L"), LinearLayout.LayoutParams(prefs.getInt("size_STICK_L", 150).coerceIn(90, 180), prefs.getInt("size_STICK_L", 150).coerceIn(90, 180)).apply { setMargins(4, 0, 4, 0) })
        center.addView(editableStick("RX", "RY", "STICK_R"), LinearLayout.LayoutParams(prefs.getInt("size_STICK_R", 150).coerceIn(90, 180), prefs.getInt("size_STICK_R", 150).coerceIn(90, 180)).apply { setMargins(4, 0, 4, 0) })
        centerColumn.addView(center, LinearLayout.LayoutParams(-1, 0, 1f))
        val system = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        listOf("SELECT", "START").forEach { system.addView(touchButton(it, it), LinearLayout.LayoutParams(88, 42).apply { setMargins(4, 4, 4, 4) }) }
        centerColumn.addView(system, LinearLayout.LayoutParams(-1, 52))
        board.addView(centerColumn, LinearLayout.LayoutParams(0, -1, 2f))

        // Right grip: Xbox ABXY layout and system buttons.
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; clipChildren = false; clipToPadding = false }
        right.addView(text("BOTONES", 14f).apply { gravity = Gravity.CENTER; setTextColor(0xFF8B9AB5.toInt()) })
        val xy = GridLayout(this).apply { columnCount = 3; rowCount = 3; clipChildren = false; clipToPadding = false }
        val pspLayout = prefs.getBoolean("psp_layout", true)
        val faceLabels = if (pspLayout) listOf("" to "", "△" to "Y", "" to "", "□" to "X", "" to "", "○" to "B", "" to "", "×" to "A", "" to "") else listOf("" to "", "Y" to "Y", "" to "", "X" to "X", "" to "", "B" to "B", "" to "", "A" to "A", "" to "")
        faceLabels.forEach { (label, key) ->
            val b = if (key.isEmpty()) TextView(this).apply { text = label } else touchButton(label, key)
            if (key.isNotEmpty()) b.setTextColor(when (key) { "A" -> 0xFF47E58A.toInt(); "B" -> 0xFFFF647C.toInt(); "X" -> 0xFF48A9FF.toInt(); else -> 0xFFFFD34F.toInt() })
            xy.addView(b, GridLayout.LayoutParams().apply { width = prefs.getInt("size_$key", buttonSize()) + 6; height = prefs.getInt("size_$key", buttonSize()); setMargins(4, 4, 4, 4) })
        }
        right.addView(xy)
        val shouldersR = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf((if (prefs.getBoolean("psp_layout", true)) "R" else "R1") to "R1", "R2" to "R2").forEach { (label, key) -> shouldersR.addView(touchButton(label, key), LinearLayout.LayoutParams(76, 44).apply { setMargins(4, 4, 4, 4) }) }
        right.addView(shouldersR)
        board.addView(right, LinearLayout.LayoutParams(0, -1, 1f))

        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Mando HID de prueba · mantené la app abierta. La compatibilidad depende de la TV Box.", 10f).apply {
            setTextColor(0xFF9AA8BF.toInt()); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun refreshEditHighlights() {
        val selectedGroup = buttonGroups[selectedEditKey]?.toSet() ?: setOf(selectedEditKey)
        editableButtonViews.forEach { (key, view) ->
            if (view is Button) {
                view.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = if (key in listOf("A", "B", "X", "Y")) 42f else 14f
                    setColor(when (key) {
                        "A" -> 0xFF063B2A.toInt(); "B" -> 0xFF421421.toInt(); "X" -> 0xFF0B3157.toInt(); "Y" -> 0xFF40330A.toInt(); else -> 0xFF14243D.toInt()
                    })
                    setStroke(3, if (editMode && key in selectedGroup) 0xFF36F29A.toInt() else if (editMode) 0xFFFF4058.toInt() else when (key) {
                        "A" -> 0xFF2BEA98.toInt(); "B" -> 0xFFFF466B.toInt(); "X" -> 0xFF22A8FF.toInt(); "Y" -> 0xFFFFC933.toInt(); else -> 0xFF22A8FF.toInt()
                    })
                }
            } else view.invalidate()
        }
    }

    private fun touchButton(label: String, key: String): Button = Button(this).apply {
        editableButtonViews[key] = this
        text = label
        textSize = when {
            label.length >= 6 -> 17f
            label.length >= 3 -> 20f
            else -> 25f
        }
        gravity = Gravity.CENTER
        includeFontPadding = false
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        isAllCaps = false
        stateListAnimator = null
        setTextColor(when (key) {
            "A" -> 0xFF062617.toInt()
            "B" -> 0xFF350811.toInt()
            "X" -> 0xFF061D35.toInt()
            "Y" -> 0xFF342700.toInt()
            else -> 0xFFF4F8FF.toInt()
        })
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = if (key in listOf("A", "B", "X", "Y")) 42f else 14f
            setColor(when (key) {
                "A" -> 0xFF063B2A.toInt()
                "B" -> 0xFF421421.toInt()
                "X" -> 0xFF0B3157.toInt()
                "Y" -> 0xFF40330A.toInt()
                else -> 0xFF14243D.toInt()
            })
            setStroke(3, if (editMode && key in (buttonGroups[selectedEditKey]?.toSet() ?: setOf(selectedEditKey))) 0xFF36F29A.toInt() else if (editMode) 0xFFFF4058.toInt() else when (key) {
                "A" -> 0xFF2BEA98.toInt()
                "B" -> 0xFFFF466B.toInt()
                "X" -> 0xFF22A8FF.toInt()
                "Y" -> 0xFFFFC933.toInt()
                else -> 0xFF22A8FF.toInt()
            })
        }
        setPadding(4, 2, 4, 2)
        stateListAnimator = null
        translationX = prefs.getInt("pos_x_$key", 0).toFloat()
        translationY = prefs.getInt("pos_y_$key", 0).toFloat()
        var lastRawX = 0f
        var lastRawY = 0f
        setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastRawX = event.rawX
                    lastRawY = event.rawY
                    if (!editMode) sendButton(key, true) else {
                        selectedEditKey = key
                        status.text = "MODO EDICIÓN · Seleccionado: $selectedEditKey · Arrastrá para mover"
                        refreshEditHighlights()
                    }
                    v.alpha = 0.72f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (editMode) {
                        val dx = event.rawX - lastRawX
                        val dy = event.rawY - lastRawY
                        val keys = buttonGroups[key] ?: listOf(key)
                        moveGroupTogether(keys, dx, dy)
                        lastRawX = event.rawX
                        lastRawY = event.rawY
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (editMode) {
                        val keys = buttonGroups[key] ?: listOf(key)
                        val editor = prefs.edit()
                        keys.forEach { groupKey ->
                            editableButtonViews[groupKey]?.let { member ->
                                editor.putInt("pos_x_$groupKey", member.translationX.toInt())
                                editor.putInt("pos_y_$groupKey", member.translationY.toInt())
                            }
                        }
                        editor.apply()
                    } else sendButton(key, false)
                    v.alpha = 1f
                    true
                }
                else -> true
            }
        }
    }

    private inner class StickView(private val xAxis: String, private val yAxis: String, private val editKey: String) : View(this@MainActivity) {
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C2A40.toInt(); style = Paint.Style.FILL }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF43D9FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
        private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF324967.toInt(); style = Paint.Style.FILL }
        private var px = 0f; private var py = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val radius = (minOf(width, height) * .37f)
            if (editMode && selectedEditKey == editKey) {
                ring.color = 0xFF103D2A.toInt()
                outline.color = 0xFF36F29A.toInt()
            } else if (editMode) {
                ring.color = 0xFF35101A.toInt()
                outline.color = 0xFFFF4058.toInt()
            } else {
                ring.color = 0xFF1C2A40.toInt()
                outline.color = 0xFF43D9FF.toInt()
            }
            canvas.drawCircle(cx, cy, radius, ring); canvas.drawCircle(cx, cy, radius, outline)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, knob)
            canvas.drawCircle(cx + px * radius * .62f, cy + py * radius * .62f, radius * .42f, outline)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val radius = minOf(width, height) * .37f
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    px = ((event.x - width / 2f) / radius).coerceIn(-1f, 1f)
                    py = ((event.y - height / 2f) / radius).coerceIn(-1f, 1f)
                    updateAxis(xAxis, px)
                    updateAxis(yAxis, py)
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    px = 0f; py = 0f
                    updateAxis(xAxis, 0f)
                    updateAxis(yAxis, 0f)
                    invalidate(); return true
                }
            }
            return true
        }
    }

    private fun buildReceiverUi() {
        disconnect()
        val outer = baseLayout()
        outer.addView(text("RECEPTOR WI-FI · GAMEPAD ANDROID", 20f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF5EEAD4.toInt())
        }, matchWrap())
        val ip = localIpv4() ?: "No se detectó IP Wi-Fi"
        outer.addView(text("IP de este dispositivo: $ip\nPuerto TCP: 45820\nConectá el mando desde otro dispositivo usando esta IP."), matchWrap())
        status = text("Receptor detenido")
        outer.addView(status, matchWrap())
        outer.addView(actionButton("Iniciar receptor") { startReceiver() }, matchWrap())
        outer.addView(actionButton("Detener receptor") { stopReceiver() }, matchWrap())
        outer.addView(actionButton("Volver al mando") { stopReceiver(); buildControllerUi() }, matchWrap())
        outer.addView(text("Eventos recibidos:", 17f), matchWrap())
        eventLog = text("Todavía no llegaron eventos.")
        outer.addView(eventLog, matchWrap())
        setContentView(ScrollView(this).apply { addView(outer) })
    }

    private fun startReceiver() {
        if (receiverRunning) { status.text = "Receptor activo en puerto 45820"; return }
        receiverRunning = true
        status.text = "Iniciando receptor…"
        thread(name = "gamepad-wifi-receiver") {
            try {
                val server = ServerSocket()
                server.reuseAddress = true
                server.bind(InetSocketAddress(45820))
                serverSocket = server
                runOnUiThread { status.text = "Receptor activo · puerto 45820" }
                while (receiverRunning) {
                    val client = server.accept()
                    thread(name = "gamepad-client") { handleClient(client) }
                }
            } catch (e: Exception) {
                if (receiverRunning) runOnUiThread {
                    status.text = "No se pudo iniciar receptor: ${e.localizedMessage ?: "error"}"
                }
            } finally {
                receiverRunning = false
                try { serverSocket?.close() } catch (_: Exception) {}
                serverSocket = null
            }
        }
    }

    private fun handleClient(client: Socket) {
        val peer = client.inetAddress?.hostAddress ?: "cliente"
        runOnUiThread { appendEvent("Conectado: $peer") }
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            while (receiverRunning) {
                val line = reader.readLine() ?: break
                runOnUiThread { appendEvent(line) }
            }
        } catch (e: Exception) {
            runOnUiThread { appendEvent("Conexión cerrada: ${e.localizedMessage ?: "desconocida"}") }
        } finally {
            try { client.close() } catch (_: Exception) {}
            runOnUiThread { appendEvent("Desconectado: $peer") }
        }
    }

    private fun appendEvent(line: String) {
        if (!::eventLog.isInitialized) return
        val old = eventLog.text.toString()
        val lines = (if (old == "Todavía no llegaron eventos.") emptyList() else old.lines()) + line
        eventLog.text = lines.takeLast(35).joinToString("\n")
    }

    private fun stopReceiver() {
        receiverRunning = false
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        if (::status.isInitialized) status.text = "Receptor detenido"
    }

    private fun localIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = if (label.length > 22) 12f else 14f
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        gravity = Gravity.CENTER
        isAllCaps = false
        includeFontPadding = false
        minHeight = 44
        minimumHeight = 44
        minWidth = 0
        minimumWidth = 0
        setPadding(14, 10, 14, 10)
        stateListAnimator = null
        setTextColor(0xFFEEF2F8.toInt())
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(0xFF101D32.toInt())
            setStroke(2, 0xFF168BFF.toInt())
        }
        setOnClickListener { click() }
    }

    private fun connectWifi() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().toIntOrNull() ?: 45820
        if (host.isBlank()) { status.text = "Escribí la IP del dispositivo receptor."; return }
        status.text = "Conectando por Wi-Fi…"
        thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 4000)
                val out = s.getOutputStream()
                try { tcpSocket?.close() } catch (_: Exception) {}
                tcpSocket = s; tcpOut = out; transport = "wifi"
                runOnUiThread { status.text = "Conectado por Wi-Fi · $host:$port" }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":2}")
            } catch (e: Exception) {
                runOnUiThread { status.text = "Wi-Fi no conectado: ${e.localizedMessage ?: "error"}" }
            }
        }
    }

    /** Diagnóstico: comprueba si Android expone el perfil HID Device. No registra todavía un mando. */
    private fun checkHidSupport() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no dispone de Bluetooth."; return }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "Bluetooth HID Device requiere Android 9 o posterior."; return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé el permiso Bluetooth y volvé a comprobar HID."; return
        }
        try {
            status.text = "Comprobando si Android ofrece Bluetooth HID…"
            val requested = a.getProfileProxy(this, hidCallback, BluetoothProfile.HID_DEVICE)
            if (!requested) {
                status.text = "Android no pudo abrir el perfil HID Device en este teléfono. No se modificó el emparejamiento."
            } else {
                status.text = "Solicitud HID enviada. Esperá unos segundos; el resultado aparecerá aquí."
            }
        } catch (e: SecurityException) {
            status.text = "Permiso Bluetooth insuficiente para comprobar HID."
        } catch (e: Exception) {
            status.text = "No se pudo comprobar HID: ${e.localizedMessage ?: "error del sistema"}"
        }
    }

    private fun startHidRegistrationAndSelectHost() {
        val a = adapter
        if (a == null || !a.isEnabled) {
            status.text = "Activá Bluetooth en Ajustes y volvé a intentarlo."
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            status.text = "Bluetooth HID Device requiere Android 9 o posterior."
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé el permiso Bluetooth y volvé a pulsar el botón."
            return
        }
        if (hidProxy == null) {
            status.text = "Abriendo servicio HID. Esperá unos segundos y volvé a pulsar."
            try { a.getProfileProxy(this, hidCallback, BluetoothProfile.HID_DEVICE) }
            catch (e: Exception) { status.text = "No se pudo abrir HID: ${e.localizedMessage}"; return }
            return
        }
        registerHidAndSelectHost()
    }

    private fun registerHidAndSelectHost() {
        val proxy = hidProxy
        if (proxy == null) { status.text = "El servicio HID aún no está listo. Volvé a pulsar."; return }
        try {
            val descriptor = byteArrayOf(
                0x05, 0x01, 0x09, 0x05, 0xA1.toByte(), 0x01,
                0x85.toByte(), 0x01, 0x05, 0x09, 0x19, 0x01, 0x29, 0x10,
                0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x10,
                0x81.toByte(), 0x02, 0x05, 0x01, 0x09, 0x39, 0x15, 0x00,
                0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
                0x75, 0x04, 0x95.toByte(), 0x01, 0x81.toByte(), 0x42,
                0x65, 0x00, 0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x33, 0x09, 0x34,
                0x15, 0x81.toByte(), 0x25, 0x7F, 0x75, 0x08, 0x95.toByte(), 0x04, 0x81.toByte(), 0x02,
                0xC0.toByte()
            )
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "Gamepad Android", "Bluetooth HID Gamepad", "OpenAI", 0x08, descriptor
            )
            val accepted = proxy.registerApp(sdp, null, null, hidExecutor, hidDeviceCallback)
            status.text = if (accepted) "Registro HID solicitado. Esperá el mensaje de registro y elegí la TV Box en sus ajustes Bluetooth."
                else "Android rechazó la solicitud de registro HID."
            showBluetoothDevicesForHid()
        } catch (e: SecurityException) {
            status.text = "Permiso Bluetooth insuficiente: ${e.localizedMessage ?: "denegado"}"
        } catch (e: Exception) {
            status.text = "No se pudo registrar HID: ${e.localizedMessage ?: "error"}"
        }
    }

    private fun showBluetoothDevicesForHid() {
        val a = adapter ?: return
        try {
            val devices = a.bondedDevices.toList()
            if (devices.isEmpty()) { status.text = "Emparejá primero la TV Box desde Ajustes Bluetooth."; return }
            val labels = devices.map { "${it.name ?: "Dispositivo"} · ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("TV Box emparejada (HID)")
                .setItems(labels) { _, which ->
                    val device = devices[which]
                    hidTarget = device
                    val ok = try { hidProxy?.connect(device) ?: false } catch (_: Exception) { false }
                    status.text = if (ok) "Solicitud de conexión HID enviada a ${device.name ?: "TV Box"}. Si no conecta, seleccioná el teléfono desde la TV Box."
                        else "No se pudo iniciar desde el teléfono. En la TV Box, buscá y seleccioná el teléfono como mando Bluetooth."
                }.setNegativeButton("Cancelar", null).show()
        } catch (e: Exception) { status.text = "No se pudieron listar dispositivos: ${e.localizedMessage}" }
    }

    private fun updateAxis(axis: String, value: Float) {
        val deadZone = prefs.getInt("dead_zone", 8).coerceIn(0, 40) / 100f
        var adjusted = value.coerceIn(-1f, 1f)
        if (kotlin.math.abs(adjusted) < deadZone) adjusted = 0f
        if (axis == "LY" && prefs.getBoolean("invert_ly", false) || axis == "RY" && prefs.getBoolean("invert_ry", false)) adjusted = -adjusted
        val scaled = (adjusted * 127f * sensitivity()).toInt().coerceIn(-127, 127)
        when (axis) {
            "LX" -> axisLX = scaled
            "LY" -> axisLY = scaled
            "RX" -> axisRX = scaled
            "RY" -> axisRY = scaled
        }
        sendHidReport()
    }

    private fun sendHidReport() {
        val proxy = hidProxy ?: return
        val target = hidTarget ?: return
        if (!hidRegistered) return
        val bitMap = listOf("A", "B", "X", "Y", "L1", "R1", "L2", "R2", "SELECT", "START", "UP", "DOWN", "LEFT", "RIGHT", "CENTER", "HOME")
        var buttons = 0
        bitMap.forEachIndexed { index, name -> if (name in heldButtons) buttons = buttons or (1 shl index) }
        val report = byteArrayOf(
            (buttons and 0xFF).toByte(), ((buttons shr 8) and 0xFF).toByte(),
            (when {
                "UP" in heldButtons && "RIGHT" in heldButtons -> 1
                "RIGHT" in heldButtons && "DOWN" in heldButtons -> 3
                "DOWN" in heldButtons && "LEFT" in heldButtons -> 5
                "LEFT" in heldButtons && "UP" in heldButtons -> 7
                "UP" in heldButtons -> 0
                "RIGHT" in heldButtons -> 2
                "DOWN" in heldButtons -> 4
                "LEFT" in heldButtons -> 6
                else -> 8
            }).toByte(), axisLX.toByte(), axisLY.toByte(), axisRX.toByte(), axisRY.toByte()
        )
        try { proxy.sendReport(target, 1, report) } catch (_: Exception) {}
    }

    private fun showBluetoothDevices() {
        val a = adapter
        if (a == null) { status.text = "Este teléfono no tiene Bluetooth."; return }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionsIfNeeded()
            status.text = "Concedé permiso Bluetooth y volvé a intentarlo."
            return
        }
        if (!a.isEnabled) { status.text = "Activá Bluetooth en Ajustes y volvé a intentarlo."; return }
        try {
            val devices = a.bondedDevices.toList()
            if (devices.isEmpty()) {
                status.text = "No hay dispositivos emparejados. Emparejá primero el receptor en Ajustes."
                return
            }
            val labels = devices.map { "${it.name ?: "Dispositivo"} · ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Elegí un receptor Bluetooth")
                .setItems(labels) { _, which -> connectBluetooth(devices[which]) }
                .setNegativeButton("Cancelar", null).show()
        } catch (_: SecurityException) { status.text = "Permiso Bluetooth denegado." }
    }

    private fun connectBluetooth(device: BluetoothDevice) {
        status.text = "Conectando Bluetooth…"
        thread {
            try {
                adapter?.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                try { btSocket?.close() } catch (_: Exception) {}
                btSocket = socket; btOut = socket.outputStream; transport = "bluetooth"
                runOnUiThread {
                    status.text = "Bluetooth RFCOMM conectado · ${device.name ?: device.address}"
                    buildControllerUi()
                }
                sendRaw("{\"type\":\"hello\",\"app\":\"GamepadAndroid\",\"version\":3}")
            } catch (e: Exception) {
                runOnUiThread { buildBluetoothUi("Bluetooth no conectado: ${e.localizedMessage ?: "error"}. Revisá que el TV Box admita RFCOMM/SPP.") }
            }
        }
    }

    private fun sendButton(name: String, down: Boolean) {
        val mapped = prefs.getString("mapping_$name", name) ?: name
        if (mapped.isBlank()) return
        if (down) {
            heldButtons.add(mapped)
            sendHidReport()
        } else {
            val minimumMs = prefs.getInt("button_press_ms", 0).coerceIn(0, 150).toLong()
            if (minimumMs > 0) {
                thread {
                    try { Thread.sleep(minimumMs) } catch (_: InterruptedException) {}
                    runOnUiThread { heldButtons.remove(mapped); sendHidReport() }
                }
            } else heldButtons.remove(mapped)
            sendHidReport()
        }
        if (down && ::status.isInitialized) status.text =
            if (hidRegistered) "Entrada HID: $name → $mapped" else "Control táctil: $name · HID no registrado"
    }

    private fun sendRaw(message: String) {
        val bytes = (message + "\n").toByteArray(Charsets.UTF_8)
        thread {
            try {
                when (transport) {
                    "wifi" -> synchronized(this) { tcpOut?.write(bytes); tcpOut?.flush() }
                    "bluetooth" -> synchronized(this) { btOut?.write(bytes); btOut?.flush() }
                    else -> { /* Offline preview: no remote transport. */ }
                }
            } catch (e: Exception) {
                runOnUiThread { if (::status.isInitialized) status.text = "Error enviando datos: ${e.localizedMessage ?: "conexión perdida"}" }
            }
        }
    }

    private fun disconnect() {
        transport = "none"
        try { tcpOut?.close() } catch (_: Exception) {}
        try { tcpSocket?.close() } catch (_: Exception) {}
        try { btOut?.close() } catch (_: Exception) {}
        try { btSocket?.close() } catch (_: Exception) {}
        tcpOut = null; tcpSocket = null; btOut = null; btSocket = null
    }

    private fun requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val missing = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 101)
        }
    }

    override fun onDestroy() {
        stopReceiver()
        disconnect()
        // No desregistrar HID aquí: Android puede destruir/recrear la Activity
        // al cambiar el estado de pantalla. La salida explícita usa APAGAR Y SALIR.
        super.onDestroy()
    }
}
