# GAMEPAD ANDROID Native v0.2

Proyecto inicial Android nativo en Kotlin. Esta versión agrega un **receptor Wi‑Fi TCP real** para probar el envío de eventos entre dos dispositivos en la misma red local.

## Incluye
- Modo mando con botones táctiles.
- Cliente Wi‑Fi TCP hacia la IP y puerto del receptor.
- Modo receptor: escucha en el puerto TCP `45820` y muestra los mensajes JSON entrantes.
- Cliente Bluetooth Classic RFCOMM/SPP para dispositivos emparejados que ofrezcan ese servicio.
- Mensajes JSON UTF‑8 separados por nueva línea.
- Aviso explícito de que USB y Bluetooth HID no son universales.

## Prueba en Android TV / TV Box
1. Abrí el proyecto en Android Studio y ejecutalo en el TV Box/Android TV y en el teléfono (dos instalaciones del mismo proyecto).
2. En la TV, abrí **Abrir modo receptor Wi‑Fi** y luego **Iniciar receptor**. La app declara la categoría de inicio de Android TV y no requiere pantalla táctil.
3. En el teléfono, ingresá la IP que muestra la TV y el puerto `45820`, y pulsá **Conectar por Wi‑Fi**.
4. Presioná los botones del teléfono y mirá los eventos en la pantalla de la TV.

## Prueba Wi‑Fi con dos dispositivos
1. Abrí el proyecto en Android Studio y ejecutalo en dos dispositivos Android conectados a la misma red Wi‑Fi.
2. En el dispositivo que recibirá, pulsá **Abrir modo receptor Wi‑Fi** y luego **Iniciar receptor**.
3. Anotá la IP que muestra la pantalla del receptor.
4. En el dispositivo mando, ingresá esa IP y el puerto `45820`, y pulsá **Conectar por Wi‑Fi**.
5. Presioná los botones. El receptor debe mostrar mensajes como `{"type":"button","name":"A","down":true}`.

Si no conecta, revisá que ambos estén en la misma red, que la red no tenga aislamiento entre clientes y que el sistema no bloquee la conexión.

## Protocolo
- `{"type":"hello","app":"GamepadAndroid","version":2}`
- `{"type":"button","name":"A","down":true}`
- `{"type":"button","name":"A","down":false}`

## Limitaciones importantes
- El receptor Wi‑Fi **recibe y muestra eventos**, pero todavía no los convierte en pulsaciones del sistema Android ni controla automáticamente otros juegos/apps de TV.
- Para controlar apps de Android TV hace falta una vía admitida por el sistema, por ejemplo integración específica del juego, servicio de accesibilidad con autorización del usuario o una interfaz compatible.
- Bluetooth de esta versión es RFCOMM/SPP, no Bluetooth HID. Muchos televisores no aceptan SPP como receptor.
- USB no está implementado como conexión de mando; depende del hardware, el rol USB host/device y soporte HID específico.
- No se ha compilado ni probado en un dispositivo físico desde este entorno. La prueba en Android Studio y en hardware real sigue pendiente.

## Abrir
Abrí la carpeta `GamepadAndroidNative_v2` en Android Studio y sincronizá Gradle.


## Importante para Android TV
Esta versión permite que la TV ejecute el receptor y muestre eventos recibidos, lo que valida la comunicación de red. No hace que los botones se conviertan automáticamente en entradas globales para otras aplicaciones. Android TV espera que las apps/juegos reciban controles compatibles mediante las APIs de entrada del sistema; una app normal no puede inyectar libremente eventos globales a otras apps. Para lograr control universal haría falta una vía de entrada de sistema o hardware compatible.
