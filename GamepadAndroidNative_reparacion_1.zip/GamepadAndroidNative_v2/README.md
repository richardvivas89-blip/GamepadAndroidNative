# Gamepad Android Native — versión reparada de diagnóstico

Proyecto Android nativo Kotlin, Java/Kotlin JVM 17.

## Cambios en esta versión
- Import explícito de `AlertDialog` para evitar el error de referencia no resuelta.
- Los botones muestran un mensaje claro si se pulsan sin conexión.
- Los eventos de pulsar/soltar se envían por una cola única para conservar el orden de los eventos.
- Los errores de envío se muestran en pantalla en lugar de quedar ocultos.

## Prueba Wi-Fi
1. Instalar la APK en dos dispositivos Android conectados a la misma red Wi-Fi.
2. En el dispositivo receptor, abrir **Abrir modo receptor Wi-Fi** y tocar **Iniciar receptor**.
3. Anotar la IP mostrada y el puerto 45820.
4. En el dispositivo mando, introducir esa IP y tocar **Conectar por Wi-Fi**.
5. Pulsar y soltar botones. El receptor debe mostrar líneas JSON con `"type":"button"`, el nombre del botón y `down:true/false`.

## Límites conocidos
- El receptor muestra los eventos recibidos; no los convierte en controles del sistema ni controla automáticamente juegos de terceros.
- Bluetooth usa RFCOMM/SPP con dispositivos compatibles y emparejados. No es emulación Bluetooth HID.
- USB HID no está implementado en esta versión.
- Esta versión se modificó por código, pero debe compilarse en GitHub Actions y probarse en dispositivos reales antes de considerarla verificada.
