GAMEPAD ANDROID HID v0.7 - MEJORAS VISUALES

Esta version ajusta el estilo de botones para evitar texto cortado:
- Texto centrado y negrita.
- Ajuste de padding y altura minima de los botones.
- Bordes celestes para los botones principales de pantalla.
- Letras A/B/X/Y mas grandes y diferenciadas.
- Botones D-pad, hombros y SELECT/START con mas espacio.

Importante: estos cambios visuales no garantizan por si solos el funcionamiento HID. Debe compilarse y probarse en el telefono y la TV Box.
