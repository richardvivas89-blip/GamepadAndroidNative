GAMEPAD ANDROID HID v0.6 — CÓDIGO FUENTE

Cambios:
- Los botones actualizan el estado HID en lugar de enviar eventos JSON por RFCOMM.
- Los sticks actualizan los cuatro ejes del informe HID.
- La cruceta actualiza el campo hat-switch.
- Botones más definidos: letras en negrita, colores diferenciados, bordes y respuesta visual al tocar.

IMPORTANTE:
Este código no se ha compilado ni probado en un dispositivo real desde este entorno. La TV Box debe aceptar el formato HID y el sistema Android debe permitir el registro HID. Compilar correctamente no garantiza compatibilidad.
