GAMEPAD ANDROID HID - VERSION DE PRUEBA v0.5

Este ZIP contiene el código fuente del proyecto Android, no un APK compilado.
Incluye un intento de registrar BluetoothHidDevice y enviar informes HID básicos.

IMPORTANTE:
- No se ha podido compilar ni probar en un teléfono/TV Box dentro de este entorno.
- Android permite BluetoothHidDevice desde API 28, pero el fabricante puede limitar su uso.
- La TV Box debe aceptar el teléfono como mando HID; el emparejamiento Bluetooth normal no garantiza compatibilidad.
- El botón principal de la pantalla de Bluetooth ahora inicia el registro HID y ofrece dispositivos emparejados.
- Mantén la aplicación en primer plano durante la prueba, porque Android puede retirar el registro HID al pasar a segundo plano.
