# GAMEPAD ANDROID HID v23

Repositorio de compilación. La fuente Android está en `GamepadAndroid_HID_v23_editor_libre_reconexion_fuente.zip` y GitHub Actions compila el APK al hacer push a `main` o al ejecutar `workflow_dispatch`.

Ver `proyecto/GamepadAndroidNative_v2/README_CAMBIOS_v23.txt` dentro del ZIP de fuente para los cambios y las limitaciones de validación.
